/* @ds-bundle: {"format":3,"namespace":"BearingPointDesignSystem_4216a8","components":[{"name":"Avatar","sourcePath":"components/core/Avatar.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Divider","sourcePath":"components/core/Divider.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Logo","sourcePath":"components/core/Logo.jsx"},{"name":"StatCard","sourcePath":"components/core/StatCard.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"Callout","sourcePath":"components/feedback/Callout.jsx"},{"name":"ProgressBar","sourcePath":"components/feedback/ProgressBar.jsx"},{"name":"Tabs","sourcePath":"components/feedback/Tabs.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Textarea","sourcePath":"components/forms/Textarea.jsx"}],"sourceHashes":{"components/core/Avatar.jsx":"34f6448b4648","components/core/Badge.jsx":"c1f7fdbb0c2e","components/core/Button.jsx":"df8df9509e19","components/core/Card.jsx":"8363e43c1200","components/core/Divider.jsx":"516310f3c3df","components/core/IconButton.jsx":"588abf3699ca","components/core/Logo.jsx":"3d44c19c28f2","components/core/StatCard.jsx":"d673d4d073e4","components/core/Tag.jsx":"f7da1e5aa5df","components/feedback/Callout.jsx":"95d4a87fbb14","components/feedback/ProgressBar.jsx":"b1004b42c9c0","components/feedback/Tabs.jsx":"c7f48a2c5c08","components/feedback/Toast.jsx":"1ad6636706a9","components/feedback/Tooltip.jsx":"7b1ac04650ed","components/forms/Checkbox.jsx":"ef7dd8bf9eda","components/forms/Input.jsx":"cdfbce9a9407","components/forms/Radio.jsx":"927830656cd0","components/forms/Select.jsx":"49aa99583b0f","components/forms/Switch.jsx":"1206377c24a4","components/forms/Textarea.jsx":"8db85812804f","ui_kits/website/site.js":"591b69787aed"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.BearingPointDesignSystem_4216a8 = window.BearingPointDesignSystem_4216a8 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** BearingPoint Avatar — square-ish by default (brand favours sharp corners),
 * or circular via shape="circle". Shows an image or initials. */
function Avatar({
  src = null,
  name = '',
  size = 40,
  shape = 'square',
  // square | circle
  style = {},
  ...rest
}) {
  const initials = name.split(' ').filter(Boolean).slice(0, 2).map(n => n[0]).join('').toUpperCase();
  const radius = shape === 'circle' ? '50%' : 'var(--radius-sm)';
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      width: size,
      height: size,
      flexShrink: 0,
      borderRadius: radius,
      overflow: 'hidden',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'var(--bp-neutral-800)',
      color: 'var(--bp-white)',
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--weight-semibold)',
      fontSize: Math.round(size * 0.4),
      letterSpacing: '0.02em',
      userSelect: 'none',
      ...style
    }
  }, rest), src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  }) : initials || '?');
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * BearingPoint Badge — a compact status/label pill or square. Neutral by
 * default; `accent` uses BearingPoint red for a genuine highlight only.
 */
function Badge({
  children,
  variant = 'neutral',
  // neutral | solid | outline | accent | subtle
  shape = 'square',
  // square | pill
  size = 'md',
  // sm | md
  style = {},
  ...rest
}) {
  const sizes = {
    sm: {
      padding: '2px 8px',
      font: '11px'
    },
    md: {
      padding: '4px 10px',
      font: '12px'
    }
  };
  const s = sizes[size] || sizes.md;
  const variants = {
    neutral: {
      background: 'var(--bp-neutral-100)',
      color: 'var(--bp-neutral-700)',
      border: '1px solid transparent'
    },
    subtle: {
      background: 'var(--bp-neutral-50)',
      color: 'var(--bp-neutral-600)',
      border: '1px solid var(--border-default)'
    },
    solid: {
      background: 'var(--bp-black)',
      color: 'var(--bp-white)',
      border: '1px solid var(--bp-black)'
    },
    outline: {
      background: 'transparent',
      color: 'var(--bp-black)',
      border: '1px solid var(--bp-black)'
    },
    accent: {
      background: 'var(--bp-red)',
      color: 'var(--bp-white)',
      border: '1px solid var(--bp-red)'
    }
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5,
      padding: s.padding,
      fontFamily: 'var(--font-mono)',
      fontSize: s.font,
      fontWeight: 'var(--weight-medium)',
      letterSpacing: '0.04em',
      textTransform: 'uppercase',
      lineHeight: 1.2,
      borderRadius: shape === 'pill' ? 'var(--radius-pill)' : 'var(--radius-sm)',
      whiteSpace: 'nowrap',
      ...variants[variant],
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * BearingPoint Button.
 * Sharp corners, confident weight. Black is the default action; the red
 * "accent" variant is reserved for the single most important call to action
 * on a view (red = highlight). Text is never red.
 */
function Button({
  children,
  variant = 'primary',
  // primary | secondary | ghost | accent
  size = 'md',
  // sm | md | lg
  iconLeft = null,
  iconRight = null,
  disabled = false,
  fullWidth = false,
  type = 'button',
  onClick,
  style = {},
  ...rest
}) {
  const sizes = {
    sm: {
      padding: '7px 14px',
      font: 'var(--text-body-sm)',
      gap: 6,
      icon: 15
    },
    md: {
      padding: '10px 20px',
      font: 'var(--text-body-md)',
      gap: 8,
      icon: 17
    },
    lg: {
      padding: '14px 28px',
      font: 'var(--text-body-lg)',
      gap: 9,
      icon: 19
    }
  };
  const s = sizes[size] || sizes.md;
  const variants = {
    primary: {
      background: 'var(--bp-black)',
      color: 'var(--bp-white)',
      border: '1px solid var(--bp-black)'
    },
    secondary: {
      background: 'var(--bp-white)',
      color: 'var(--bp-black)',
      border: '1px solid var(--bp-black)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--bp-black)',
      border: '1px solid transparent'
    },
    accent: {
      background: 'var(--bp-red)',
      color: 'var(--bp-white)',
      border: '1px solid var(--bp-red)'
    }
  };
  const base = {
    display: fullWidth ? 'flex' : 'inline-flex',
    width: fullWidth ? '100%' : 'auto',
    alignItems: 'center',
    justifyContent: 'center',
    gap: s.gap,
    padding: s.padding,
    fontFamily: 'var(--font-sans)',
    fontSize: s.font,
    fontWeight: 'var(--weight-semibold)',
    lineHeight: 1,
    letterSpacing: '0.005em',
    borderRadius: 'var(--radius-sm)',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.4 : 1,
    transition: 'background var(--duration-fast) var(--ease-standard), color var(--duration-fast) var(--ease-standard), transform var(--duration-fast) var(--ease-standard)',
    userSelect: 'none',
    whiteSpace: 'nowrap',
    ...variants[variant],
    ...style
  };
  const hoverMap = {
    primary: 'var(--bp-neutral-800)',
    accent: 'var(--bp-red-hover)',
    secondary: 'var(--bp-neutral-50)',
    ghost: 'var(--bp-neutral-100)'
  };
  const onEnter = e => {
    if (disabled) return;
    if (variant === 'secondary' || variant === 'ghost') e.currentTarget.style.background = hoverMap[variant];else e.currentTarget.style.background = hoverMap[variant];
  };
  const onLeave = e => {
    if (disabled) return;
    e.currentTarget.style.background = variants[variant].background;
  };
  const onDown = e => {
    if (!disabled) e.currentTarget.style.transform = 'translateY(1px)';
  };
  const onUp = e => {
    if (!disabled) e.currentTarget.style.transform = 'none';
  };
  const iconStyle = {
    width: s.icon,
    height: s.icon,
    flexShrink: 0,
    display: 'inline-flex'
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: disabled,
    onClick: onClick,
    style: base,
    onMouseEnter: onEnter,
    onMouseLeave: e => {
      onLeave(e);
      onUp(e);
    },
    onMouseDown: onDown,
    onMouseUp: onUp
  }, rest), iconLeft && /*#__PURE__*/React.createElement("span", {
    style: iconStyle
  }, iconLeft), children, iconRight && /*#__PURE__*/React.createElement("span", {
    style: iconStyle
  }, iconRight));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * BearingPoint Card — crisp white surface, hairline border, minimal shadow.
 * `interactive` adds a hover lift. `accentBar` draws a thin red rule along
 * the top edge to mark a highlighted card.
 */
function Card({
  children,
  interactive = false,
  accentBar = false,
  padding = 'var(--space-6)',
  style = {},
  onClick,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", _extends({
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      position: 'relative',
      background: 'var(--surface-card)',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-md)',
      padding,
      boxShadow: interactive && hover ? 'var(--shadow-lg)' : 'var(--shadow-sm)',
      transform: interactive && hover ? 'translateY(-2px)' : 'none',
      transition: 'box-shadow var(--duration-base) var(--ease-standard), transform var(--duration-base) var(--ease-standard)',
      cursor: interactive ? 'pointer' : 'default',
      overflow: 'hidden',
      ...style
    }
  }, rest), accentBar && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      height: 'var(--border-width-heavy)',
      background: 'var(--bp-red)'
    }
  }), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Divider.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** BearingPoint Divider — a hairline rule. `accent` makes it a short heavy
 * red bar (the brand's signature emphasis mark). */
function Divider({
  orientation = 'horizontal',
  // horizontal | vertical
  accent = false,
  style = {},
  ...rest
}) {
  if (accent) {
    return /*#__PURE__*/React.createElement("hr", _extends({
      style: {
        border: 0,
        height: 'var(--border-width-heavy)',
        width: 56,
        background: 'var(--bp-red)',
        margin: 0,
        ...style
      }
    }, rest));
  }
  if (orientation === 'vertical') {
    return /*#__PURE__*/React.createElement("span", _extends({
      style: {
        display: 'inline-block',
        width: 1,
        alignSelf: 'stretch',
        background: 'var(--border-default)',
        ...style
      }
    }, rest));
  }
  return /*#__PURE__*/React.createElement("hr", _extends({
    style: {
      border: 0,
      height: 1,
      width: '100%',
      background: 'var(--border-default)',
      margin: 0,
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { Divider });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Divider.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * BearingPoint IconButton — square, icon-only control. Pass a single icon
 * element as children (e.g. a Lucide SVG).
 */
function IconButton({
  children,
  variant = 'ghost',
  // ghost | solid | outline | accent
  size = 'md',
  // sm | md | lg
  disabled = false,
  'aria-label': ariaLabel,
  onClick,
  style = {},
  ...rest
}) {
  const sizes = {
    sm: 30,
    md: 38,
    lg: 46
  };
  const iconSizes = {
    sm: 16,
    md: 18,
    lg: 22
  };
  const dim = sizes[size] || sizes.md;
  const variants = {
    ghost: {
      background: 'transparent',
      color: 'var(--bp-black)',
      border: '1px solid transparent'
    },
    solid: {
      background: 'var(--bp-black)',
      color: 'var(--bp-white)',
      border: '1px solid var(--bp-black)'
    },
    outline: {
      background: 'var(--bp-white)',
      color: 'var(--bp-black)',
      border: '1px solid var(--border-default)'
    },
    accent: {
      background: 'var(--bp-red)',
      color: 'var(--bp-white)',
      border: '1px solid var(--bp-red)'
    }
  };
  const hover = {
    ghost: 'var(--bp-neutral-100)',
    solid: 'var(--bp-neutral-800)',
    outline: 'var(--bp-neutral-50)',
    accent: 'var(--bp-red-hover)'
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    "aria-label": ariaLabel,
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: e => {
      if (!disabled) e.currentTarget.style.background = hover[variant];
    },
    onMouseLeave: e => {
      if (!disabled) e.currentTarget.style.background = variants[variant].background;
    },
    style: {
      width: dim,
      height: dim,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: 'var(--radius-sm)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.4 : 1,
      transition: 'background var(--duration-fast) var(--ease-standard)',
      ...variants[variant],
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      width: iconSizes[size],
      height: iconSizes[size],
      display: 'inline-flex'
    }
  }, children));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Logo.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * BearingPoint Logo. Renders the wordmark or the B° symbol as an <img>.
 * Because the artwork lives in this design system's /assets, pass `src`
 * (or `basePath`) so the URL resolves from wherever you mount it. Defaults
 * assume the assets sit at `assets/logos/` relative to the page.
 */
function Logo({
  variant = 'wordmark',
  // wordmark | symbol
  color = 'black',
  // black | white
  height = 28,
  basePath = 'assets/logos',
  src = null,
  style = {},
  ...rest
}) {
  const file = variant === 'symbol' ? color === 'white' ? 'bearingpoint-symbol-white.png' : 'bearingpoint-symbol-black.png' : color === 'white' ? 'bearingpoint-logotype-white.png' : 'bearingpoint-logotype-black.png';
  const url = src || `${basePath}/${file}`;
  return /*#__PURE__*/React.createElement("img", _extends({
    src: url,
    alt: "BearingPoint",
    style: {
      height,
      width: 'auto',
      display: 'block',
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { Logo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Logo.jsx", error: String((e && e.message) || e) }); }

// components/core/StatCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * BearingPoint StatCard — a big figure with label and optional delta. The
 * figure is mono; a positive/negative delta may be tinted red to highlight
 * a key data point (the one place red touches near-text is allowed as a
 * highlight of a data point, not running copy).
 */
function StatCard({
  value,
  label,
  eyebrow = null,
  delta = null,
  // e.g. "+18%"
  highlight = false,
  // renders the figure in red
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      padding: 'var(--space-6)',
      background: 'var(--surface-card)',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-md)',
      ...style
    }
  }, rest), eyebrow && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-eyebrow)',
      textTransform: 'uppercase',
      letterSpacing: 'var(--tracking-eyebrow)',
      color: 'var(--text-secondary)'
    }
  }, eyebrow), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 40,
      fontWeight: 'var(--weight-semibold)',
      letterSpacing: '-0.02em',
      lineHeight: 1,
      color: highlight ? 'var(--bp-red)' : 'var(--text-primary)'
    }
  }, value), delta && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 14,
      fontWeight: 'var(--weight-medium)',
      color: 'var(--bp-red)'
    }
  }, delta)), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-body-sm)',
      color: 'var(--text-secondary)',
      lineHeight: 1.4
    }
  }, label));
}
Object.assign(__ds_scope, { StatCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/StatCard.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * BearingPoint Tag — removable/selectable keyword chip (title case, sentence
 * text — unlike Badge which is a mono status token).
 */
function Tag({
  children,
  selected = false,
  onRemove = null,
  onClick,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    onClick: onClick,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 7,
      padding: '5px 12px',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-body-sm)',
      fontWeight: 'var(--weight-medium)',
      lineHeight: 1.3,
      borderRadius: 'var(--radius-pill)',
      cursor: onClick ? 'pointer' : 'default',
      background: selected ? 'var(--bp-black)' : 'var(--bp-white)',
      color: selected ? 'var(--bp-white)' : 'var(--bp-neutral-700)',
      border: selected ? '1px solid var(--bp-black)' : '1px solid var(--border-default)',
      transition: 'all var(--duration-fast) var(--ease-standard)',
      ...style
    }
  }, rest), children, onRemove && /*#__PURE__*/React.createElement("button", {
    "aria-label": "Remove",
    onClick: e => {
      e.stopPropagation();
      onRemove(e);
    },
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: 16,
      height: 16,
      borderRadius: '50%',
      border: 'none',
      cursor: 'pointer',
      background: 'transparent',
      color: 'inherit',
      fontSize: 13,
      lineHeight: 1,
      padding: 0
    }
  }, "\xD7"));
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Callout.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * BearingPoint Callout — a bordered message block. A left rule marks it; the
 * `highlight` tone uses the red rule to draw attention to a key message.
 */
function Callout({
  children,
  title = null,
  tone = 'neutral',
  // neutral | highlight
  icon = null,
  style = {},
  ...rest
}) {
  const rule = tone === 'highlight' ? 'var(--bp-red)' : 'var(--bp-black)';
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      gap: 12,
      borderLeft: `var(--border-width-heavy) solid ${rule}`,
      background: 'var(--bp-neutral-50)',
      padding: 'var(--space-4) var(--space-5)',
      borderRadius: '0 var(--radius-sm) var(--radius-sm) 0',
      ...style
    }
  }, rest), icon && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 18,
      height: 18,
      flexShrink: 0,
      marginTop: 1,
      color: 'var(--text-primary)'
    }
  }, icon), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 3
    }
  }, title && /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 'var(--weight-semibold)',
      fontSize: 'var(--text-body-md)',
      color: 'var(--text-primary)'
    }
  }, title), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-body-sm)',
      color: 'var(--text-secondary)',
      lineHeight: 1.55
    }
  }, children)));
}
Object.assign(__ds_scope, { Callout });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Callout.jsx", error: String((e && e.message) || e) }); }

// components/feedback/ProgressBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** BearingPoint ProgressBar — thin track. Black fill by default; `accent`
 * fills with BearingPoint red to highlight a headline metric. */
function ProgressBar({
  value = 0,
  // 0–100
  accent = false,
  showLabel = false,
  height = 6,
  style = {},
  ...rest
}) {
  const pct = Math.max(0, Math.min(100, value));
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      height,
      background: 'var(--bp-neutral-200)',
      borderRadius: 'var(--radius-pill)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: `${pct}%`,
      height: '100%',
      background: accent ? 'var(--bp-red)' : 'var(--bp-black)',
      borderRadius: 'var(--radius-pill)',
      transition: 'width var(--duration-slow) var(--ease-out)'
    }
  })), showLabel && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-body-sm)',
      color: 'var(--text-secondary)',
      minWidth: 40,
      textAlign: 'right'
    }
  }, pct, "%"));
}
Object.assign(__ds_scope, { ProgressBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/ProgressBar.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tabs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * BearingPoint Tabs — underline style. The active tab is marked by a heavy
 * black underline; hover shows a faint one. Controlled or uncontrolled.
 */
function Tabs({
  tabs = [],
  // [{id, label}] or string[]
  value = null,
  defaultValue = null,
  onChange,
  style = {},
  ...rest
}) {
  const items = tabs.map(t => typeof t === 'string' ? {
    id: t,
    label: t
  } : t);
  const [internal, setInternal] = React.useState(defaultValue ?? (items[0] && items[0].id));
  const active = value ?? internal;
  const [hover, setHover] = React.useState(null);
  const select = id => {
    setInternal(id);
    onChange && onChange(id);
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "tablist",
    style: {
      display: 'flex',
      gap: 4,
      borderBottom: '1px solid var(--border-default)',
      ...style
    }
  }, rest), items.map(t => {
    const isActive = t.id === active;
    return /*#__PURE__*/React.createElement("button", {
      key: t.id,
      role: "tab",
      "aria-selected": isActive,
      onClick: () => select(t.id),
      onMouseEnter: () => setHover(t.id),
      onMouseLeave: () => setHover(null),
      style: {
        appearance: 'none',
        background: 'none',
        border: 'none',
        cursor: 'pointer',
        fontFamily: 'var(--font-sans)',
        fontSize: 'var(--text-body-md)',
        fontWeight: isActive ? 'var(--weight-semibold)' : 'var(--weight-medium)',
        color: isActive ? 'var(--text-primary)' : 'var(--text-secondary)',
        padding: '12px 14px',
        position: 'relative',
        whiteSpace: 'nowrap',
        transition: 'color var(--duration-fast) var(--ease-standard)'
      }
    }, t.label, /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        left: 0,
        right: 0,
        bottom: -1,
        height: isActive ? 2 : hover === t.id ? 2 : 0,
        background: isActive ? 'var(--bp-black)' : 'var(--bp-neutral-300)',
        transition: 'height var(--duration-fast) var(--ease-standard)'
      }
    }));
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** BearingPoint Toast — a self-contained notification surface. Black by
 * default; `accent` shows a red leading rule for an important message. */
function Toast({
  title = null,
  children,
  accent = false,
  onClose = null,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "status",
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 12,
      background: 'var(--bp-neutral-900)',
      color: 'var(--bp-white)',
      borderLeft: accent ? 'var(--border-width-heavy) solid var(--bp-red)' : 'var(--border-width-heavy) solid var(--bp-neutral-900)',
      padding: 'var(--space-4) var(--space-5)',
      borderRadius: 'var(--radius-sm)',
      boxShadow: 'var(--shadow-lg)',
      minWidth: 280,
      maxWidth: 420,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, title && /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 'var(--weight-semibold)',
      fontSize: 'var(--text-body-md)'
    }
  }, title), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-body-sm)',
      color: 'var(--text-inverse-soft)',
      lineHeight: 1.5
    }
  }, children)), onClose && /*#__PURE__*/React.createElement("button", {
    "aria-label": "Dismiss",
    onClick: onClose,
    style: {
      background: 'none',
      border: 'none',
      color: 'var(--text-inverse-soft)',
      cursor: 'pointer',
      fontSize: 16,
      lineHeight: 1,
      padding: 2
    }
  }, "\xD7"));
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** BearingPoint Tooltip — black bubble on hover/focus. Wraps its trigger. */
function Tooltip({
  children,
  label,
  placement = 'top',
  // top | bottom
  style = {},
  ...rest
}) {
  const [open, setOpen] = React.useState(false);
  const pos = placement === 'bottom' ? {
    top: 'calc(100% + 8px)'
  } : {
    bottom: 'calc(100% + 8px)'
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      position: 'relative',
      display: 'inline-flex'
    },
    onMouseEnter: () => setOpen(true),
    onMouseLeave: () => setOpen(false),
    onFocus: () => setOpen(true),
    onBlur: () => setOpen(false)
  }, rest), children, open && /*#__PURE__*/React.createElement("span", {
    role: "tooltip",
    style: {
      position: 'absolute',
      left: '50%',
      transform: 'translateX(-50%)',
      ...pos,
      background: 'var(--bp-black)',
      color: 'var(--bp-white)',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-caption)',
      fontWeight: 'var(--weight-medium)',
      padding: '6px 10px',
      borderRadius: 'var(--radius-sm)',
      whiteSpace: 'nowrap',
      boxShadow: 'var(--shadow-md)',
      zIndex: 50,
      pointerEvents: 'none',
      ...style
    }
  }, label));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** BearingPoint Checkbox — square, black when checked. */
function Checkbox({
  checked = false,
  onChange,
  label = null,
  disabled = false,
  id,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: id,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 10,
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    role: "checkbox",
    "aria-checked": checked,
    onClick: () => !disabled && onChange && onChange(!checked),
    style: {
      width: 18,
      height: 18,
      flexShrink: 0,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      border: `1.5px solid ${checked ? 'var(--bp-black)' : 'var(--border-strong)'}`,
      background: checked ? 'var(--bp-black)' : 'var(--bp-white)',
      borderRadius: 'var(--radius-sm)',
      transition: 'all var(--duration-fast) var(--ease-standard)'
    }
  }, checked && /*#__PURE__*/React.createElement("svg", {
    width: "11",
    height: "11",
    viewBox: "0 0 12 12",
    fill: "none"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M2.5 6.2L4.8 8.5L9.5 3.5",
    stroke: "#fff",
    strokeWidth: "1.8",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }))), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-body-md)',
      color: 'var(--text-primary)'
    }
  }, label), /*#__PURE__*/React.createElement("input", _extends({
    id: id,
    type: "checkbox",
    checked: checked,
    disabled: disabled,
    onChange: e => onChange && onChange(e.target.checked),
    style: {
      position: 'absolute',
      opacity: 0,
      width: 0,
      height: 0
    }
  }, rest)));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** BearingPoint text Input. Sharp corners, black focus with red ring. */
function Input({
  label = null,
  hint = null,
  error = null,
  iconLeft = null,
  size = 'md',
  // sm | md | lg
  disabled = false,
  id,
  style = {},
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const sizes = {
    sm: {
      padding: '7px 10px',
      font: 'var(--text-body-sm)'
    },
    md: {
      padding: '10px 12px',
      font: 'var(--text-body-md)'
    },
    lg: {
      padding: '13px 14px',
      font: 'var(--text-body-lg)'
    }
  };
  const s = sizes[size] || sizes.md;
  const borderColor = error ? 'var(--bp-red)' : focus ? 'var(--bp-black)' : 'var(--border-default)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: id,
    style: {
      fontSize: 'var(--text-body-sm)',
      fontWeight: 'var(--weight-medium)',
      color: 'var(--text-primary)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      background: disabled ? 'var(--bp-neutral-50)' : 'var(--bp-white)',
      border: `1px solid ${borderColor}`,
      borderRadius: 'var(--radius-sm)',
      padding: s.padding,
      boxShadow: focus && !error ? 'var(--shadow-focus)' : 'none',
      transition: 'border-color var(--duration-fast) var(--ease-standard), box-shadow var(--duration-fast) var(--ease-standard)'
    }
  }, iconLeft && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 16,
      height: 16,
      display: 'inline-flex',
      color: 'var(--text-muted)'
    }
  }, iconLeft), /*#__PURE__*/React.createElement("input", _extends({
    id: id,
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      flex: 1,
      border: 'none',
      outline: 'none',
      background: 'transparent',
      fontFamily: 'var(--font-sans)',
      fontSize: s.font,
      color: 'var(--text-primary)',
      minWidth: 0
    }
  }, rest))), error && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-caption)',
      color: 'var(--bp-red)'
    }
  }, error), hint && !error && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-caption)',
      color: 'var(--text-muted)'
    }
  }, hint));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** BearingPoint Radio — circular, black dot when selected. */
function Radio({
  checked = false,
  onChange,
  label = null,
  name,
  value,
  disabled = false,
  id,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: id,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 10,
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    role: "radio",
    "aria-checked": checked,
    onClick: () => !disabled && onChange && onChange(value),
    style: {
      width: 18,
      height: 18,
      flexShrink: 0,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      border: `1.5px solid ${checked ? 'var(--bp-black)' : 'var(--border-strong)'}`,
      background: 'var(--bp-white)',
      borderRadius: '50%',
      transition: 'all var(--duration-fast) var(--ease-standard)'
    }
  }, checked && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 9,
      height: 9,
      borderRadius: '50%',
      background: 'var(--bp-black)'
    }
  })), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-body-md)',
      color: 'var(--text-primary)'
    }
  }, label), /*#__PURE__*/React.createElement("input", _extends({
    id: id,
    type: "radio",
    name: name,
    value: value,
    checked: checked,
    disabled: disabled,
    onChange: () => onChange && onChange(value),
    style: {
      position: 'absolute',
      opacity: 0,
      width: 0,
      height: 0
    }
  }, rest)));
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** BearingPoint Select — native select with brand styling and a chevron. */
function Select({
  label = null,
  hint = null,
  error = null,
  options = [],
  // [{value, label}] or string[]
  placeholder = null,
  disabled = false,
  id,
  style = {},
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const borderColor = error ? 'var(--bp-red)' : focus ? 'var(--bp-black)' : 'var(--border-default)';
  const opts = options.map(o => typeof o === 'string' ? {
    value: o,
    label: o
  } : o);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: id,
    style: {
      fontSize: 'var(--text-body-sm)',
      fontWeight: 'var(--weight-medium)',
      color: 'var(--text-primary)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex'
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    id: id,
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      appearance: 'none',
      WebkitAppearance: 'none',
      width: '100%',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-body-md)',
      color: 'var(--text-primary)',
      background: disabled ? 'var(--bp-neutral-50)' : 'var(--bp-white)',
      border: `1px solid ${borderColor}`,
      borderRadius: 'var(--radius-sm)',
      padding: '10px 36px 10px 12px',
      outline: 'none',
      cursor: 'pointer',
      boxShadow: focus && !error ? 'var(--shadow-focus)' : 'none',
      transition: 'border-color var(--duration-fast) var(--ease-standard), box-shadow var(--duration-fast) var(--ease-standard)'
    }
  }, rest), placeholder && /*#__PURE__*/React.createElement("option", {
    value: ""
  }, placeholder), opts.map(o => /*#__PURE__*/React.createElement("option", {
    key: o.value,
    value: o.value
  }, o.label))), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      right: 12,
      top: '50%',
      transform: 'translateY(-50%)',
      pointerEvents: 'none',
      color: 'var(--text-secondary)',
      fontSize: 12
    }
  }, "\u25BE")), error && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-caption)',
      color: 'var(--bp-red)'
    }
  }, error), hint && !error && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-caption)',
      color: 'var(--text-muted)'
    }
  }, hint));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** BearingPoint Switch — pill toggle, black track when on. */
function Switch({
  checked = false,
  onChange,
  label = null,
  disabled = false,
  id,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: id,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 10,
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    role: "switch",
    "aria-checked": checked,
    onClick: () => !disabled && onChange && onChange(!checked),
    style: {
      width: 40,
      height: 22,
      flexShrink: 0,
      borderRadius: 'var(--radius-pill)',
      background: checked ? 'var(--bp-black)' : 'var(--bp-neutral-300)',
      position: 'relative',
      transition: 'background var(--duration-base) var(--ease-standard)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 2,
      left: checked ? 20 : 2,
      width: 18,
      height: 18,
      borderRadius: '50%',
      background: 'var(--bp-white)',
      boxShadow: 'var(--shadow-sm)',
      transition: 'left var(--duration-base) var(--ease-out)'
    }
  })), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-body-md)',
      color: 'var(--text-primary)'
    }
  }, label), /*#__PURE__*/React.createElement("input", _extends({
    id: id,
    type: "checkbox",
    checked: checked,
    disabled: disabled,
    onChange: e => onChange && onChange(e.target.checked),
    style: {
      position: 'absolute',
      opacity: 0,
      width: 0,
      height: 0
    }
  }, rest)));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/forms/Textarea.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** BearingPoint Textarea — multi-line input matching Input styling. */
function Textarea({
  label = null,
  hint = null,
  error = null,
  rows = 4,
  disabled = false,
  id,
  style = {},
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const borderColor = error ? 'var(--bp-red)' : focus ? 'var(--bp-black)' : 'var(--border-default)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: id,
    style: {
      fontSize: 'var(--text-body-sm)',
      fontWeight: 'var(--weight-medium)',
      color: 'var(--text-primary)'
    }
  }, label), /*#__PURE__*/React.createElement("textarea", _extends({
    id: id,
    rows: rows,
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-body-md)',
      color: 'var(--text-primary)',
      background: disabled ? 'var(--bp-neutral-50)' : 'var(--bp-white)',
      border: `1px solid ${borderColor}`,
      borderRadius: 'var(--radius-sm)',
      padding: '10px 12px',
      resize: 'vertical',
      outline: 'none',
      boxShadow: focus && !error ? 'var(--shadow-focus)' : 'none',
      transition: 'border-color var(--duration-fast) var(--ease-standard), box-shadow var(--duration-fast) var(--ease-standard)',
      lineHeight: 1.5
    }
  }, rest)), error && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-caption)',
      color: 'var(--bp-red)'
    }
  }, error), hint && !error && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-caption)',
      color: 'var(--text-muted)'
    }
  }, hint));
}
Object.assign(__ds_scope, { Textarea });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Textarea.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/site.js
try { (() => {
/* BearingPoint — Website UI kit.
   A brand-accurate recreation of the bearingpoint.com marketing surface,
   built on the design system primitives. Screens: Home, Insights, Article,
   Contact. Exposes { SiteApp } to window. */

(function () {
  const R = React;
  const DS = window.BearingPointDesignSystem_4216a8;
  const {
    Button,
    IconButton,
    Badge,
    Tag,
    Card,
    StatCard,
    Tabs,
    Divider,
    Callout,
    Input,
    Select,
    Logo
  } = DS;

  /* ---- tiny inline icon set (Lucide-style, 2px stroke) ---- */
  const Icon = ({
    d,
    size = 20,
    ...p
  }) => R.createElement('svg', {
    viewBox: '0 0 24 24',
    width: size,
    height: size,
    fill: 'none',
    stroke: 'currentColor',
    strokeWidth: 2,
    strokeLinecap: 'round',
    strokeLinejoin: 'round',
    ...p
  }, Array.isArray(d) ? d.map((x, i) => R.createElement('path', {
    key: i,
    d: x
  })) : R.createElement('path', {
    d
  }));
  const Arrow = p => Icon({
    d: 'M5 12h14M13 6l6 6-6 6',
    ...p
  });
  const Menu = p => Icon({
    d: ['M3 6h18', 'M3 12h18', 'M3 18h18'],
    ...p
  });
  const SearchI = p => R.createElement('svg', {
    viewBox: '0 0 24 24',
    width: p.size || 20,
    height: p.size || 20,
    fill: 'none',
    stroke: 'currentColor',
    strokeWidth: 2,
    strokeLinecap: 'round'
  }, R.createElement('circle', {
    cx: 11,
    cy: 11,
    r: 7
  }), R.createElement('path', {
    d: 'M21 21l-4.3-4.3'
  }));
  const Globe = p => R.createElement('svg', {
    viewBox: '0 0 24 24',
    width: p.size || 18,
    height: p.size || 18,
    fill: 'none',
    stroke: 'currentColor',
    strokeWidth: 2
  }, R.createElement('circle', {
    cx: 12,
    cy: 12,
    r: 9
  }), R.createElement('path', {
    d: 'M3 12h18M12 3c2.5 2.5 2.5 15 0 18M12 3c-2.5 2.5-2.5 15 0 18'
  }));
  const LOGO = '../../assets/logos';

  /* ============================ HEADER ============================ */
  function Header({
    nav,
    go
  }) {
    const items = ['Industries', 'Services', 'Insights', 'Careers', 'About'];
    const map = {
      Insights: 'insights',
      About: 'home',
      Industries: 'home',
      Services: 'home',
      Careers: 'home'
    };
    return R.createElement('header', {
      style: {
        position: 'sticky',
        top: 0,
        zIndex: 40,
        background: 'var(--bp-white)',
        borderBottom: '1px solid var(--border-default)'
      }
    }, R.createElement('div', {
      style: {
        maxWidth: 1200,
        margin: '0 auto',
        padding: '0 32px',
        height: 72,
        display: 'flex',
        alignItems: 'center',
        gap: 40
      }
    }, R.createElement('a', {
      onClick: () => go('home'),
      style: {
        cursor: 'pointer',
        display: 'flex'
      }
    }, R.createElement(Logo, {
      basePath: LOGO,
      height: 22
    })), R.createElement('nav', {
      style: {
        display: 'flex',
        gap: 26,
        flex: 1
      }
    }, items.map(it => R.createElement('a', {
      key: it,
      onClick: () => go(map[it]),
      style: {
        fontSize: 15,
        fontWeight: 500,
        color: nav === map[it] && it === 'Insights' ? 'var(--bp-black)' : 'var(--text-secondary)',
        cursor: 'pointer',
        textDecoration: 'none',
        paddingBottom: 2,
        borderBottom: nav === 'insights' && it === 'Insights' ? '2px solid var(--bp-black)' : '2px solid transparent'
      }
    }, it))), R.createElement('div', {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 8
      }
    }, R.createElement(IconButton, {
      variant: 'ghost',
      'aria-label': 'Search'
    }, R.createElement(SearchI, null)), R.createElement('span', {
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 5,
        fontSize: 13,
        color: 'var(--text-secondary)',
        fontFamily: 'var(--font-mono)'
      }
    }, R.createElement(Globe, null), 'EN'), R.createElement(Button, {
      variant: 'primary',
      size: 'sm',
      onClick: () => go('contact')
    }, 'Get in touch'))));
  }

  /* ============================ FOOTER ============================ */
  function Footer({
    go
  }) {
    const cols = [['Industries', ['Banking', 'Insurance', 'Automotive', 'Public sector', 'Utilities']], ['Services', ['Strategy', 'Finance & Risk', 'Operations', 'Technology', 'People']], ['Company', ['About us', 'Careers', 'Newsroom', 'Investors', 'Contact']]];
    return R.createElement('footer', {
      style: {
        background: 'var(--bp-black)',
        color: 'var(--bp-white)',
        marginTop: 0
      }
    }, R.createElement('div', {
      style: {
        maxWidth: 1200,
        margin: '0 auto',
        padding: '64px 32px 40px',
        display: 'grid',
        gridTemplateColumns: '1.4fr 1fr 1fr 1fr',
        gap: 40
      }
    }, R.createElement('div', null, R.createElement(Logo, {
      basePath: LOGO,
      color: 'white',
      height: 24
    }), R.createElement('p', {
      style: {
        marginTop: 18,
        fontSize: 14,
        lineHeight: 1.6,
        color: 'var(--text-inverse-soft)',
        maxWidth: 240
      }
    }, 'Management and technology consultancy with European roots and a global reach.')), cols.map(([h, links]) => R.createElement('div', {
      key: h
    }, R.createElement('div', {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 11,
        textTransform: 'uppercase',
        letterSpacing: '.14em',
        color: 'var(--text-inverse-soft)',
        marginBottom: 16
      }
    }, h), R.createElement('div', {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 10
      }
    }, links.map(l => R.createElement('a', {
      key: l,
      onClick: () => go(l === 'Insights' ? 'insights' : l === 'Contact' ? 'contact' : 'home'),
      style: {
        fontSize: 14,
        color: 'var(--bp-white)',
        textDecoration: 'none',
        cursor: 'pointer',
        opacity: 0.85
      }
    }, l)))))), R.createElement('div', {
      style: {
        borderTop: '1px solid var(--border-inverse)'
      }
    }, R.createElement('div', {
      style: {
        maxWidth: 1200,
        margin: '0 auto',
        padding: '20px 32px',
        display: 'flex',
        justifyContent: 'space-between',
        fontFamily: 'var(--font-mono)',
        fontSize: 12,
        color: 'var(--text-inverse-soft)'
      }
    }, R.createElement('span', null, '© BEARINGPOINT 2026'), R.createElement('span', null, 'Privacy · Terms · Cookies'))));
  }

  /* ============================ HOME ============================ */
  function Home({
    go
  }) {
    const services = [['Strategy & Growth', 'Set direction and unlock new sources of value.'], ['Finance & Risk', 'Steer performance, capital and regulatory change.'], ['Operations', 'Design operating models that actually run.'], ['Technology', 'Modernise platforms and ship real outcomes.'], ['People & Change', 'Bring the organisation with you.'], ['Data & AI', 'Turn data into decisions at scale.']];
    const insights = [['Report', 'The connected enterprise: a 2026 outlook', 'How European firms are re-platforming for AI-era operating models.'], ['Article', 'Cost-to-serve, rebuilt', 'A pragmatic path to a leaner, faster back office.'], ['Study', 'Trust in digital public services', 'What 12,000 citizens told us about the state that works.']];
    return R.createElement('div', null, /* Hero */
    R.createElement('section', {
      style: {
        background: 'var(--bp-black)',
        color: 'var(--bp-white)'
      }
    }, R.createElement('div', {
      style: {
        maxWidth: 1200,
        margin: '0 auto',
        padding: '96px 32px 104px'
      }
    }, R.createElement('div', {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 12,
        textTransform: 'uppercase',
        letterSpacing: '.14em',
        color: 'var(--text-inverse-soft)',
        marginBottom: 22
      }
    }, 'Management & Technology Consulting'), R.createElement('h1', {
      style: {
        fontSize: 76,
        lineHeight: 1.02,
        letterSpacing: '-0.025em',
        fontWeight: 800,
        margin: 0,
        maxWidth: 900
      }
    }, 'Beyond the ', R.createElement('span', {
      style: {
        color: 'var(--bp-red)'
      }
    }, 'obvious.')), R.createElement('p', {
      style: {
        fontSize: 20,
        lineHeight: 1.55,
        color: 'var(--text-inverse-soft)',
        maxWidth: 560,
        marginTop: 26
      }
    }, 'We help organisations across Europe and beyond turn ambition into measurable results — with clarity, pace and staying power.'), R.createElement('div', {
      style: {
        display: 'flex',
        gap: 12,
        marginTop: 34
      }
    }, R.createElement(Button, {
      variant: 'accent',
      size: 'lg',
      iconRight: R.createElement(Arrow, null),
      onClick: () => go('insights')
    }, 'Explore our thinking'), R.createElement(Button, {
      variant: 'secondary',
      size: 'lg',
      onClick: () => go('contact'),
      style: {
        background: 'transparent',
        color: '#fff',
        borderColor: 'rgba(255,255,255,.4)'
      }
    }, 'Work with us')))), /* Stats band */
    R.createElement('section', {
      style: {
        background: 'var(--bp-deep-red)',
        color: 'var(--bp-white)'
      }
    }, R.createElement('div', {
      style: {
        maxWidth: 1200,
        margin: '0 auto',
        padding: '48px 32px',
        display: 'grid',
        gridTemplateColumns: 'repeat(4,1fr)',
        gap: 32
      }
    }, [['24', 'countries'], ['€1bn+', 'annual revenue'], ['6,000+', 'people'], ['1000s', 'of projects delivered']].map(([v, l]) => R.createElement('div', {
      key: l
    }, R.createElement('div', {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 44,
        fontWeight: 600,
        letterSpacing: '-0.02em'
      }
    }, v), R.createElement('div', {
      style: {
        fontSize: 14,
        color: 'var(--text-inverse-soft)',
        marginTop: 4
      }
    }, l))))), /* Services */
    R.createElement('section', {
      style: {
        maxWidth: 1200,
        margin: '0 auto',
        padding: '88px 32px'
      }
    }, R.createElement('div', {
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'flex-end',
        marginBottom: 36
      }
    }, R.createElement('div', null, R.createElement('hr', {
      style: {
        border: 0,
        height: 3,
        width: 56,
        background: 'var(--bp-red)',
        margin: '0 0 18px'
      }
    }), R.createElement('h2', {
      style: {
        fontSize: 40,
        fontWeight: 700,
        letterSpacing: '-0.02em',
        margin: 0
      }
    }, 'What we do')), R.createElement(Button, {
      variant: 'ghost',
      iconRight: R.createElement(Arrow, null)
    }, 'All services')), R.createElement('div', {
      style: {
        display: 'grid',
        gridTemplateColumns: 'repeat(3,1fr)',
        gap: 16
      }
    }, services.map(([t, d], i) => R.createElement(Card, {
      key: t,
      interactive: true,
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 10,
        minHeight: 172
      }
    }, R.createElement('div', {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 12,
        color: 'var(--text-muted)'
      }
    }, String(i + 1).padStart(2, '0')), R.createElement('div', {
      style: {
        fontSize: 20,
        fontWeight: 700,
        letterSpacing: '-0.01em'
      }
    }, t), R.createElement('div', {
      style: {
        fontSize: 14,
        color: 'var(--text-secondary)',
        lineHeight: 1.55,
        flex: 1
      }
    }, d), R.createElement('div', {
      style: {
        color: 'var(--bp-black)'
      }
    }, R.createElement(Arrow, {
      size: 18
    })))))), /* Insights */
    R.createElement('section', {
      style: {
        background: 'var(--bp-neutral-50)',
        borderTop: '1px solid var(--border-default)'
      }
    }, R.createElement('div', {
      style: {
        maxWidth: 1200,
        margin: '0 auto',
        padding: '88px 32px'
      }
    }, R.createElement('div', {
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'flex-end',
        marginBottom: 36
      }
    }, R.createElement('div', null, R.createElement('hr', {
      style: {
        border: 0,
        height: 3,
        width: 56,
        background: 'var(--bp-red)',
        margin: '0 0 18px'
      }
    }), R.createElement('h2', {
      style: {
        fontSize: 40,
        fontWeight: 700,
        letterSpacing: '-0.02em',
        margin: 0
      }
    }, 'Latest thinking')), R.createElement(Button, {
      variant: 'ghost',
      iconRight: R.createElement(Arrow, null),
      onClick: () => go('insights')
    }, 'All insights')), R.createElement('div', {
      style: {
        display: 'grid',
        gridTemplateColumns: 'repeat(3,1fr)',
        gap: 16
      }
    }, insights.map(([k, t, d]) => R.createElement(Card, {
      key: t,
      interactive: true,
      padding: '0',
      onClick: () => go('article'),
      style: {
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column'
      }
    }, R.createElement('div', {
      style: {
        height: 150,
        background: 'var(--bp-neutral-200)',
        display: 'flex',
        alignItems: 'flex-end',
        padding: 14
      }
    }, R.createElement(Badge, {
      variant: 'solid'
    }, k)), R.createElement('div', {
      style: {
        padding: 20,
        display: 'flex',
        flexDirection: 'column',
        gap: 8
      }
    }, R.createElement('div', {
      style: {
        fontSize: 18,
        fontWeight: 700,
        lineHeight: 1.25,
        letterSpacing: '-0.01em'
      }
    }, t), R.createElement('div', {
      style: {
        fontSize: 14,
        color: 'var(--text-secondary)',
        lineHeight: 1.5
      }
    }, d))))))), /* CTA */
    R.createElement('section', {
      style: {
        background: 'var(--bp-red)',
        color: 'var(--bp-white)'
      }
    }, R.createElement('div', {
      style: {
        maxWidth: 1200,
        margin: '0 auto',
        padding: '72px 32px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        gap: 32,
        flexWrap: 'wrap'
      }
    }, R.createElement('h2', {
      style: {
        fontSize: 42,
        fontWeight: 800,
        letterSpacing: '-0.02em',
        margin: 0,
        maxWidth: 640,
        lineHeight: 1.05
      }
    }, 'Let’s turn your ambition into results.'), R.createElement(Button, {
      variant: 'secondary',
      size: 'lg',
      onClick: () => go('contact'),
      style: {
        background: '#fff',
        color: '#000',
        borderColor: '#fff'
      }
    }, 'Get in touch'))));
  }

  /* ============================ INSIGHTS LIST ============================ */
  function Insights({
    go
  }) {
    const [tab, setTab] = R.useState('All');
    const posts = [['Report', 'The connected enterprise: a 2026 outlook', 'Technology'], ['Article', 'Cost-to-serve, rebuilt', 'Finance & Risk'], ['Study', 'Trust in digital public services', 'Public sector'], ['Article', 'The operating model for AI', 'Technology'], ['Report', 'Europe’s energy transition scorecard', 'Utilities'], ['Article', 'Underwriting at machine speed', 'Insurance']];
    return R.createElement('div', null, R.createElement('section', {
      style: {
        background: 'var(--bp-neutral-50)',
        borderBottom: '1px solid var(--border-default)'
      }
    }, R.createElement('div', {
      style: {
        maxWidth: 1200,
        margin: '0 auto',
        padding: '64px 32px 40px'
      }
    }, R.createElement('hr', {
      style: {
        border: 0,
        height: 3,
        width: 56,
        background: 'var(--bp-red)',
        margin: '0 0 18px'
      }
    }), R.createElement('h1', {
      style: {
        fontSize: 56,
        fontWeight: 800,
        letterSpacing: '-0.025em',
        margin: 0
      }
    }, 'Insights'), R.createElement('p', {
      style: {
        fontSize: 18,
        color: 'var(--text-secondary)',
        maxWidth: 560,
        marginTop: 14
      }
    }, 'Research, points of view and field notes from our work across industries.'))), R.createElement('div', {
      style: {
        maxWidth: 1200,
        margin: '0 auto',
        padding: '32px 32px 0'
      }
    }, R.createElement(Tabs, {
      tabs: ['All', 'Reports', 'Articles', 'Studies'],
      value: tab,
      onChange: setTab
    })), R.createElement('section', {
      style: {
        maxWidth: 1200,
        margin: '0 auto',
        padding: '32px 32px 88px'
      }
    }, R.createElement('div', {
      style: {
        display: 'grid',
        gridTemplateColumns: 'repeat(3,1fr)',
        gap: 16
      }
    }, posts.map(([k, t, cat]) => R.createElement(Card, {
      key: t,
      interactive: true,
      padding: '0',
      onClick: () => go('article'),
      style: {
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column'
      }
    }, R.createElement('div', {
      style: {
        height: 160,
        background: k === 'Report' ? 'var(--bp-deep-red)' : 'var(--bp-neutral-200)',
        display: 'flex',
        alignItems: 'flex-end',
        padding: 14
      }
    }, R.createElement(Badge, {
      variant: k === 'Report' ? 'accent' : 'solid'
    }, k)), R.createElement('div', {
      style: {
        padding: 20,
        display: 'flex',
        flexDirection: 'column',
        gap: 10,
        flex: 1
      }
    }, R.createElement('div', {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 11,
        textTransform: 'uppercase',
        letterSpacing: '.1em',
        color: 'var(--text-muted)'
      }
    }, cat), R.createElement('div', {
      style: {
        fontSize: 19,
        fontWeight: 700,
        lineHeight: 1.25,
        letterSpacing: '-0.01em',
        flex: 1
      }
    }, t), R.createElement('div', {
      style: {
        color: 'var(--bp-black)'
      }
    }, R.createElement(Arrow, {
      size: 18
    }))))))));
  }

  /* ============================ ARTICLE ============================ */
  function Article({
    go
  }) {
    return R.createElement('div', null, R.createElement('article', {
      style: {
        maxWidth: 760,
        margin: '0 auto',
        padding: '56px 32px 40px'
      }
    }, R.createElement('a', {
      onClick: () => go('insights'),
      style: {
        fontSize: 14,
        color: 'var(--text-secondary)',
        cursor: 'pointer',
        display: 'inline-flex',
        gap: 6,
        alignItems: 'center'
      }
    }, '← Back to Insights'), R.createElement('div', {
      style: {
        display: 'flex',
        gap: 10,
        margin: '28px 0 16px'
      }
    }, R.createElement(Badge, {
      variant: 'accent'
    }, 'Report'), R.createElement(Badge, {
      variant: 'outline',
      shape: 'pill'
    }, 'Technology')), R.createElement('h1', {
      style: {
        fontSize: 46,
        fontWeight: 800,
        letterSpacing: '-0.025em',
        lineHeight: 1.05,
        margin: 0
      }
    }, 'The connected enterprise: a 2026 outlook'), R.createElement('p', {
      style: {
        fontSize: 20,
        color: 'var(--text-secondary)',
        lineHeight: 1.5,
        marginTop: 18
      }
    }, 'How European firms are re-platforming for AI-era operating models — and what separates the leaders.'), R.createElement('div', {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        marginTop: 24,
        paddingTop: 20,
        borderTop: '1px solid var(--border-default)'
      }
    }, R.createElement(DS.Avatar, {
      name: 'Marta Lindqvist'
    }), R.createElement('div', null, R.createElement('div', {
      style: {
        fontSize: 14,
        fontWeight: 600
      }
    }, 'Marta Lindqvist'), R.createElement('div', {
      style: {
        fontSize: 13,
        color: 'var(--text-muted)',
        fontFamily: 'var(--font-mono)'
      }
    }, 'Partner, Technology · 8 min read')))), R.createElement('div', {
      style: {
        maxWidth: 900,
        margin: '0 auto',
        padding: '0 32px'
      }
    }, R.createElement('div', {
      style: {
        height: 340,
        background: 'var(--bp-neutral-200)',
        borderRadius: 'var(--radius-md)'
      }
    })), R.createElement('article', {
      style: {
        maxWidth: 720,
        margin: '0 auto',
        padding: '40px 32px 24px',
        fontSize: 17,
        lineHeight: 1.7,
        color: 'var(--bp-neutral-800)'
      }
    }, R.createElement('p', null, 'The most resilient organisations of the last decade share a quiet trait: they treated their operating model as a product, not a project. As AI moves from pilot to platform, that discipline is about to matter more than ever.'), R.createElement('h3', {
      style: {
        fontSize: 26,
        fontWeight: 700,
        letterSpacing: '-0.01em',
        margin: '32px 0 12px',
        color: 'var(--bp-black)'
      }
    }, 'Three shifts that separate the leaders'), R.createElement('p', null, 'Across 24 markets we see the same pattern repeat. Leaders decouple decisions from systems, invest ahead of certainty, and hold the line on a small number of measurable outcomes.'), R.createElement(Callout, {
      tone: 'highlight',
      title: 'Key finding',
      style: {
        margin: '24px 0'
      }
    }, 'Firms that platformed their data foundation first moved 2.3× faster on subsequent AI initiatives.'), R.createElement('p', null, 'The lesson is not to move faster on everything — it is to be relentless about the few things that compound.')), R.createElement('section', {
      style: {
        background: 'var(--bp-neutral-50)',
        borderTop: '1px solid var(--border-default)',
        marginTop: 32
      }
    }, R.createElement('div', {
      style: {
        maxWidth: 1200,
        margin: '0 auto',
        padding: '56px 32px'
      }
    }, R.createElement('h3', {
      style: {
        fontSize: 24,
        fontWeight: 700,
        margin: '0 0 24px'
      }
    }, 'Related insights'), R.createElement('div', {
      style: {
        display: 'grid',
        gridTemplateColumns: 'repeat(3,1fr)',
        gap: 16
      }
    }, [['Article', 'The operating model for AI'], ['Article', 'Cost-to-serve, rebuilt'], ['Study', 'Trust in digital public services']].map(([k, t]) => R.createElement(Card, {
      key: t,
      interactive: true,
      onClick: () => go('article'),
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 10
      }
    }, R.createElement(Badge, {
      variant: 'neutral'
    }, k), R.createElement('div', {
      style: {
        fontSize: 17,
        fontWeight: 700,
        lineHeight: 1.3
      }
    }, t)))))));
  }

  /* ============================ CONTACT ============================ */
  function Contact() {
    const [sent, setSent] = R.useState(false);
    return R.createElement('section', {
      style: {
        maxWidth: 1200,
        margin: '0 auto',
        padding: '64px 32px 96px',
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: 64
      }
    }, R.createElement('div', null, R.createElement('hr', {
      style: {
        border: 0,
        height: 3,
        width: 56,
        background: 'var(--bp-red)',
        margin: '0 0 18px'
      }
    }), R.createElement('h1', {
      style: {
        fontSize: 52,
        fontWeight: 800,
        letterSpacing: '-0.025em',
        margin: 0,
        lineHeight: 1.05
      }
    }, 'Get in touch'), R.createElement('p', {
      style: {
        fontSize: 18,
        color: 'var(--text-secondary)',
        lineHeight: 1.6,
        marginTop: 18,
        maxWidth: 420
      }
    }, 'Tell us about the challenge in front of you. We’ll come back within two working days.'), R.createElement('div', {
      style: {
        marginTop: 32,
        display: 'flex',
        flexDirection: 'column',
        gap: 16
      }
    }, [['Offices', '24 countries across Europe, the Americas & Asia'], ['Media', 'press@bearingpoint.com'], ['Careers', 'Join 6,000+ people who think beyond the obvious']].map(([h, d]) => R.createElement('div', {
      key: h,
      style: {
        paddingLeft: 14,
        borderLeft: '3px solid var(--bp-black)'
      }
    }, R.createElement('div', {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 11,
        textTransform: 'uppercase',
        letterSpacing: '.12em',
        color: 'var(--text-muted)'
      }
    }, h), R.createElement('div', {
      style: {
        fontSize: 15,
        marginTop: 4
      }
    }, d))))), R.createElement(Card, {
      style: {
        alignSelf: 'start'
      }
    }, sent ? R.createElement('div', {
      style: {
        padding: '32px 8px',
        textAlign: 'center'
      }
    }, R.createElement('div', {
      style: {
        fontSize: 22,
        fontWeight: 700
      }
    }, 'Thank you.'), R.createElement('p', {
      style: {
        color: 'var(--text-secondary)',
        marginTop: 8
      }
    }, 'Your message is on its way. We’ll be in touch shortly.'), R.createElement(Button, {
      variant: 'ghost',
      onClick: () => setSent(false),
      style: {
        marginTop: 8
      }
    }, 'Send another')) : R.createElement('div', {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 16
      }
    }, R.createElement('div', {
      style: {
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: 12
      }
    }, R.createElement(Input, {
      label: 'First name',
      placeholder: 'Anna'
    }), R.createElement(Input, {
      label: 'Last name',
      placeholder: 'Berg'
    })), R.createElement(Input, {
      label: 'Work email',
      placeholder: 'you@company.com',
      type: 'email'
    }), R.createElement(Select, {
      label: 'Topic',
      placeholder: 'Choose…',
      options: ['Strategy & Growth', 'Finance & Risk', 'Operations', 'Technology', 'People & Change']
    }), R.createElement(DS.Textarea, {
      label: 'How can we help?',
      rows: 4,
      placeholder: 'Tell us about your challenge…'
    }), R.createElement(Button, {
      variant: 'accent',
      fullWidth: true,
      onClick: () => setSent(true)
    }, 'Send message'))));
  }

  /* ============================ APP ============================ */
  function SiteApp() {
    const [route, setRoute] = R.useState('home');
    const go = r => {
      setRoute(r);
      document.getElementById('scroll-root') && (document.getElementById('scroll-root').scrollTop = 0);
    };
    const pages = {
      home: Home,
      insights: Insights,
      article: Article,
      contact: Contact
    };
    const Page = pages[route] || Home;
    return R.createElement('div', {
      className: 'bp-base',
      style: {
        minHeight: '100%'
      }
    }, R.createElement(Header, {
      nav: route,
      go
    }), R.createElement(Page, {
      go
    }), R.createElement(Footer, {
      go
    }));
  }
  window.SiteApp = SiteApp;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/site.js", error: String((e && e.message) || e) }); }

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Divider = __ds_scope.Divider;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Logo = __ds_scope.Logo;

__ds_ns.StatCard = __ds_scope.StatCard;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Callout = __ds_scope.Callout;

__ds_ns.ProgressBar = __ds_scope.ProgressBar;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Textarea = __ds_scope.Textarea;

})();
