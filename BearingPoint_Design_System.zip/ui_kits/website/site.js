/* BearingPoint — Website UI kit.
   A brand-accurate recreation of the bearingpoint.com marketing surface,
   built on the design system primitives. Screens: Home, Insights, Article,
   Contact. Exposes { SiteApp } to window. */

(function () {
  const R = React;
  const DS = window.BearingPointDesignSystem_4216a8;
  const { Button, IconButton, Badge, Tag, Card, StatCard, Tabs, Divider, Callout, Input, Select, Logo } = DS;

  /* ---- tiny inline icon set (Lucide-style, 2px stroke) ---- */
  const Icon = ({ d, size = 20, ...p }) => (
    R.createElement('svg', { viewBox: '0 0 24 24', width: size, height: size, fill: 'none', stroke: 'currentColor', strokeWidth: 2, strokeLinecap: 'round', strokeLinejoin: 'round', ...p },
      Array.isArray(d) ? d.map((x, i) => R.createElement('path', { key: i, d: x })) : R.createElement('path', { d })));
  const Arrow = (p) => Icon({ d: 'M5 12h14M13 6l6 6-6 6', ...p });
  const Menu = (p) => Icon({ d: ['M3 6h18', 'M3 12h18', 'M3 18h18'], ...p });
  const SearchI = (p) => R.createElement('svg', { viewBox: '0 0 24 24', width: p.size||20, height: p.size||20, fill: 'none', stroke: 'currentColor', strokeWidth: 2, strokeLinecap: 'round' }, R.createElement('circle', { cx: 11, cy: 11, r: 7 }), R.createElement('path', { d: 'M21 21l-4.3-4.3' }));
  const Globe = (p) => R.createElement('svg', { viewBox: '0 0 24 24', width: p.size||18, height: p.size||18, fill: 'none', stroke: 'currentColor', strokeWidth: 2 }, R.createElement('circle', { cx: 12, cy: 12, r: 9 }), R.createElement('path', { d: 'M3 12h18M12 3c2.5 2.5 2.5 15 0 18M12 3c-2.5 2.5-2.5 15 0 18' }));

  const LOGO = '../../assets/logos';

  /* ============================ HEADER ============================ */
  function Header({ nav, go }) {
    const items = ['Industries', 'Services', 'Insights', 'Careers', 'About'];
    const map = { Insights: 'insights', About: 'home', Industries: 'home', Services: 'home', Careers: 'home' };
    return R.createElement('header', { style: { position: 'sticky', top: 0, zIndex: 40, background: 'var(--bp-white)', borderBottom: '1px solid var(--border-default)' } },
      R.createElement('div', { style: { maxWidth: 1200, margin: '0 auto', padding: '0 32px', height: 72, display: 'flex', alignItems: 'center', gap: 40 } },
        R.createElement('a', { onClick: () => go('home'), style: { cursor: 'pointer', display: 'flex' } },
          R.createElement(Logo, { basePath: LOGO, height: 22 })),
        R.createElement('nav', { style: { display: 'flex', gap: 26, flex: 1 } },
          items.map((it) => R.createElement('a', {
            key: it, onClick: () => go(map[it]),
            style: { fontSize: 15, fontWeight: 500, color: nav === map[it] && it === 'Insights' ? 'var(--bp-black)' : 'var(--text-secondary)', cursor: 'pointer', textDecoration: 'none', paddingBottom: 2, borderBottom: (nav === 'insights' && it === 'Insights') ? '2px solid var(--bp-black)' : '2px solid transparent' }
          }, it))),
        R.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: 8 } },
          R.createElement(IconButton, { variant: 'ghost', 'aria-label': 'Search' }, R.createElement(SearchI, null)),
          R.createElement('span', { style: { display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 13, color: 'var(--text-secondary)', fontFamily: 'var(--font-mono)' } }, R.createElement(Globe, null), 'EN'),
          R.createElement(Button, { variant: 'primary', size: 'sm', onClick: () => go('contact') }, 'Get in touch'))));
  }

  /* ============================ FOOTER ============================ */
  function Footer({ go }) {
    const cols = [
      ['Industries', ['Banking', 'Insurance', 'Automotive', 'Public sector', 'Utilities']],
      ['Services', ['Strategy', 'Finance & Risk', 'Operations', 'Technology', 'People']],
      ['Company', ['About us', 'Careers', 'Newsroom', 'Investors', 'Contact']],
    ];
    return R.createElement('footer', { style: { background: 'var(--bp-black)', color: 'var(--bp-white)', marginTop: 0 } },
      R.createElement('div', { style: { maxWidth: 1200, margin: '0 auto', padding: '64px 32px 40px', display: 'grid', gridTemplateColumns: '1.4fr 1fr 1fr 1fr', gap: 40 } },
        R.createElement('div', null,
          R.createElement(Logo, { basePath: LOGO, color: 'white', height: 24 }),
          R.createElement('p', { style: { marginTop: 18, fontSize: 14, lineHeight: 1.6, color: 'var(--text-inverse-soft)', maxWidth: 240 } }, 'Management and technology consultancy with European roots and a global reach.')),
        cols.map(([h, links]) => R.createElement('div', { key: h },
          R.createElement('div', { style: { fontFamily: 'var(--font-mono)', fontSize: 11, textTransform: 'uppercase', letterSpacing: '.14em', color: 'var(--text-inverse-soft)', marginBottom: 16 } }, h),
          R.createElement('div', { style: { display: 'flex', flexDirection: 'column', gap: 10 } },
            links.map((l) => R.createElement('a', { key: l, onClick: () => go(l === 'Insights' ? 'insights' : l === 'Contact' ? 'contact' : 'home'), style: { fontSize: 14, color: 'var(--bp-white)', textDecoration: 'none', cursor: 'pointer', opacity: 0.85 } }, l)))))),
      R.createElement('div', { style: { borderTop: '1px solid var(--border-inverse)' } },
        R.createElement('div', { style: { maxWidth: 1200, margin: '0 auto', padding: '20px 32px', display: 'flex', justifyContent: 'space-between', fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text-inverse-soft)' } },
          R.createElement('span', null, '© BEARINGPOINT 2026'),
          R.createElement('span', null, 'Privacy · Terms · Cookies'))));
  }

  /* ============================ HOME ============================ */
  function Home({ go }) {
    const services = [
      ['Strategy & Growth', 'Set direction and unlock new sources of value.'],
      ['Finance & Risk', 'Steer performance, capital and regulatory change.'],
      ['Operations', 'Design operating models that actually run.'],
      ['Technology', 'Modernise platforms and ship real outcomes.'],
      ['People & Change', 'Bring the organisation with you.'],
      ['Data & AI', 'Turn data into decisions at scale.'],
    ];
    const insights = [
      ['Report', 'The connected enterprise: a 2026 outlook', 'How European firms are re-platforming for AI-era operating models.'],
      ['Article', 'Cost-to-serve, rebuilt', 'A pragmatic path to a leaner, faster back office.'],
      ['Study', 'Trust in digital public services', 'What 12,000 citizens told us about the state that works.'],
    ];
    return R.createElement('div', null,
      /* Hero */
      R.createElement('section', { style: { background: 'var(--bp-black)', color: 'var(--bp-white)' } },
        R.createElement('div', { style: { maxWidth: 1200, margin: '0 auto', padding: '96px 32px 104px' } },
          R.createElement('div', { style: { fontFamily: 'var(--font-mono)', fontSize: 12, textTransform: 'uppercase', letterSpacing: '.14em', color: 'var(--text-inverse-soft)', marginBottom: 22 } }, 'Management & Technology Consulting'),
          R.createElement('h1', { style: { fontSize: 76, lineHeight: 1.02, letterSpacing: '-0.025em', fontWeight: 800, margin: 0, maxWidth: 900 } },
            'Beyond the ', R.createElement('span', { style: { color: 'var(--bp-red)' } }, 'obvious.')),
          R.createElement('p', { style: { fontSize: 20, lineHeight: 1.55, color: 'var(--text-inverse-soft)', maxWidth: 560, marginTop: 26 } }, 'We help organisations across Europe and beyond turn ambition into measurable results — with clarity, pace and staying power.'),
          R.createElement('div', { style: { display: 'flex', gap: 12, marginTop: 34 } },
            R.createElement(Button, { variant: 'accent', size: 'lg', iconRight: R.createElement(Arrow, null), onClick: () => go('insights') }, 'Explore our thinking'),
            R.createElement(Button, { variant: 'secondary', size: 'lg', onClick: () => go('contact'), style: { background: 'transparent', color: '#fff', borderColor: 'rgba(255,255,255,.4)' } }, 'Work with us')))),
      /* Stats band */
      R.createElement('section', { style: { background: 'var(--bp-deep-red)', color: 'var(--bp-white)' } },
        R.createElement('div', { style: { maxWidth: 1200, margin: '0 auto', padding: '48px 32px', display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 32 } },
          [['24', 'countries'], ['€1bn+', 'annual revenue'], ['6,000+', 'people'], ['1000s', 'of projects delivered']].map(([v, l]) =>
            R.createElement('div', { key: l },
              R.createElement('div', { style: { fontFamily: 'var(--font-mono)', fontSize: 44, fontWeight: 600, letterSpacing: '-0.02em' } }, v),
              R.createElement('div', { style: { fontSize: 14, color: 'var(--text-inverse-soft)', marginTop: 4 } }, l))))),
      /* Services */
      R.createElement('section', { style: { maxWidth: 1200, margin: '0 auto', padding: '88px 32px' } },
        R.createElement('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 36 } },
          R.createElement('div', null,
            R.createElement('hr', { style: { border: 0, height: 3, width: 56, background: 'var(--bp-red)', margin: '0 0 18px' } }),
            R.createElement('h2', { style: { fontSize: 40, fontWeight: 700, letterSpacing: '-0.02em', margin: 0 } }, 'What we do')),
          R.createElement(Button, { variant: 'ghost', iconRight: R.createElement(Arrow, null) }, 'All services')),
        R.createElement('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 16 } },
          services.map(([t, d], i) => R.createElement(Card, { key: t, interactive: true, style: { display: 'flex', flexDirection: 'column', gap: 10, minHeight: 172 } },
            R.createElement('div', { style: { fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text-muted)' } }, String(i + 1).padStart(2, '0')),
            R.createElement('div', { style: { fontSize: 20, fontWeight: 700, letterSpacing: '-0.01em' } }, t),
            R.createElement('div', { style: { fontSize: 14, color: 'var(--text-secondary)', lineHeight: 1.55, flex: 1 } }, d),
            R.createElement('div', { style: { color: 'var(--bp-black)' } }, R.createElement(Arrow, { size: 18 })))))),
      /* Insights */
      R.createElement('section', { style: { background: 'var(--bp-neutral-50)', borderTop: '1px solid var(--border-default)' } },
        R.createElement('div', { style: { maxWidth: 1200, margin: '0 auto', padding: '88px 32px' } },
          R.createElement('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 36 } },
            R.createElement('div', null,
              R.createElement('hr', { style: { border: 0, height: 3, width: 56, background: 'var(--bp-red)', margin: '0 0 18px' } }),
              R.createElement('h2', { style: { fontSize: 40, fontWeight: 700, letterSpacing: '-0.02em', margin: 0 } }, 'Latest thinking')),
            R.createElement(Button, { variant: 'ghost', iconRight: R.createElement(Arrow, null), onClick: () => go('insights') }, 'All insights')),
          R.createElement('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 16 } },
            insights.map(([k, t, d]) => R.createElement(Card, { key: t, interactive: true, padding: '0', onClick: () => go('article'), style: { overflow: 'hidden', display: 'flex', flexDirection: 'column' } },
              R.createElement('div', { style: { height: 150, background: 'var(--bp-neutral-200)', display: 'flex', alignItems: 'flex-end', padding: 14 } }, R.createElement(Badge, { variant: 'solid' }, k)),
              R.createElement('div', { style: { padding: 20, display: 'flex', flexDirection: 'column', gap: 8 } },
                R.createElement('div', { style: { fontSize: 18, fontWeight: 700, lineHeight: 1.25, letterSpacing: '-0.01em' } }, t),
                R.createElement('div', { style: { fontSize: 14, color: 'var(--text-secondary)', lineHeight: 1.5 } }, d))))))),
      /* CTA */
      R.createElement('section', { style: { background: 'var(--bp-red)', color: 'var(--bp-white)' } },
        R.createElement('div', { style: { maxWidth: 1200, margin: '0 auto', padding: '72px 32px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 32, flexWrap: 'wrap' } },
          R.createElement('h2', { style: { fontSize: 42, fontWeight: 800, letterSpacing: '-0.02em', margin: 0, maxWidth: 640, lineHeight: 1.05 } }, 'Let’s turn your ambition into results.'),
          R.createElement(Button, { variant: 'secondary', size: 'lg', onClick: () => go('contact'), style: { background: '#fff', color: '#000', borderColor: '#fff' } }, 'Get in touch'))));
  }

  /* ============================ INSIGHTS LIST ============================ */
  function Insights({ go }) {
    const [tab, setTab] = R.useState('All');
    const posts = [
      ['Report', 'The connected enterprise: a 2026 outlook', 'Technology'],
      ['Article', 'Cost-to-serve, rebuilt', 'Finance & Risk'],
      ['Study', 'Trust in digital public services', 'Public sector'],
      ['Article', 'The operating model for AI', 'Technology'],
      ['Report', 'Europe’s energy transition scorecard', 'Utilities'],
      ['Article', 'Underwriting at machine speed', 'Insurance'],
    ];
    return R.createElement('div', null,
      R.createElement('section', { style: { background: 'var(--bp-neutral-50)', borderBottom: '1px solid var(--border-default)' } },
        R.createElement('div', { style: { maxWidth: 1200, margin: '0 auto', padding: '64px 32px 40px' } },
          R.createElement('hr', { style: { border: 0, height: 3, width: 56, background: 'var(--bp-red)', margin: '0 0 18px' } }),
          R.createElement('h1', { style: { fontSize: 56, fontWeight: 800, letterSpacing: '-0.025em', margin: 0 } }, 'Insights'),
          R.createElement('p', { style: { fontSize: 18, color: 'var(--text-secondary)', maxWidth: 560, marginTop: 14 } }, 'Research, points of view and field notes from our work across industries.'))),
      R.createElement('div', { style: { maxWidth: 1200, margin: '0 auto', padding: '32px 32px 0' } },
        R.createElement(Tabs, { tabs: ['All', 'Reports', 'Articles', 'Studies'], value: tab, onChange: setTab })),
      R.createElement('section', { style: { maxWidth: 1200, margin: '0 auto', padding: '32px 32px 88px' } },
        R.createElement('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 16 } },
          posts.map(([k, t, cat]) => R.createElement(Card, { key: t, interactive: true, padding: '0', onClick: () => go('article'), style: { overflow: 'hidden', display: 'flex', flexDirection: 'column' } },
            R.createElement('div', { style: { height: 160, background: k === 'Report' ? 'var(--bp-deep-red)' : 'var(--bp-neutral-200)', display: 'flex', alignItems: 'flex-end', padding: 14 } }, R.createElement(Badge, { variant: k === 'Report' ? 'accent' : 'solid' }, k)),
            R.createElement('div', { style: { padding: 20, display: 'flex', flexDirection: 'column', gap: 10, flex: 1 } },
              R.createElement('div', { style: { fontFamily: 'var(--font-mono)', fontSize: 11, textTransform: 'uppercase', letterSpacing: '.1em', color: 'var(--text-muted)' } }, cat),
              R.createElement('div', { style: { fontSize: 19, fontWeight: 700, lineHeight: 1.25, letterSpacing: '-0.01em', flex: 1 } }, t),
              R.createElement('div', { style: { color: 'var(--bp-black)' } }, R.createElement(Arrow, { size: 18 }))))))));
  }

  /* ============================ ARTICLE ============================ */
  function Article({ go }) {
    return R.createElement('div', null,
      R.createElement('article', { style: { maxWidth: 760, margin: '0 auto', padding: '56px 32px 40px' } },
        R.createElement('a', { onClick: () => go('insights'), style: { fontSize: 14, color: 'var(--text-secondary)', cursor: 'pointer', display: 'inline-flex', gap: 6, alignItems: 'center' } }, '← Back to Insights'),
        R.createElement('div', { style: { display: 'flex', gap: 10, margin: '28px 0 16px' } }, R.createElement(Badge, { variant: 'accent' }, 'Report'), R.createElement(Badge, { variant: 'outline', shape: 'pill' }, 'Technology')),
        R.createElement('h1', { style: { fontSize: 46, fontWeight: 800, letterSpacing: '-0.025em', lineHeight: 1.05, margin: 0 } }, 'The connected enterprise: a 2026 outlook'),
        R.createElement('p', { style: { fontSize: 20, color: 'var(--text-secondary)', lineHeight: 1.5, marginTop: 18 } }, 'How European firms are re-platforming for AI-era operating models — and what separates the leaders.'),
        R.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: 12, marginTop: 24, paddingTop: 20, borderTop: '1px solid var(--border-default)' } },
          R.createElement(DS.Avatar, { name: 'Marta Lindqvist' }),
          R.createElement('div', null,
            R.createElement('div', { style: { fontSize: 14, fontWeight: 600 } }, 'Marta Lindqvist'),
            R.createElement('div', { style: { fontSize: 13, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' } }, 'Partner, Technology · 8 min read')))),
      R.createElement('div', { style: { maxWidth: 900, margin: '0 auto', padding: '0 32px' } },
        R.createElement('div', { style: { height: 340, background: 'var(--bp-neutral-200)', borderRadius: 'var(--radius-md)' } })),
      R.createElement('article', { style: { maxWidth: 720, margin: '0 auto', padding: '40px 32px 24px', fontSize: 17, lineHeight: 1.7, color: 'var(--bp-neutral-800)' } },
        R.createElement('p', null, 'The most resilient organisations of the last decade share a quiet trait: they treated their operating model as a product, not a project. As AI moves from pilot to platform, that discipline is about to matter more than ever.'),
        R.createElement('h3', { style: { fontSize: 26, fontWeight: 700, letterSpacing: '-0.01em', margin: '32px 0 12px', color: 'var(--bp-black)' } }, 'Three shifts that separate the leaders'),
        R.createElement('p', null, 'Across 24 markets we see the same pattern repeat. Leaders decouple decisions from systems, invest ahead of certainty, and hold the line on a small number of measurable outcomes.'),
        R.createElement(Callout, { tone: 'highlight', title: 'Key finding', style: { margin: '24px 0' } }, 'Firms that platformed their data foundation first moved 2.3× faster on subsequent AI initiatives.'),
        R.createElement('p', null, 'The lesson is not to move faster on everything — it is to be relentless about the few things that compound.')),
      R.createElement('section', { style: { background: 'var(--bp-neutral-50)', borderTop: '1px solid var(--border-default)', marginTop: 32 } },
        R.createElement('div', { style: { maxWidth: 1200, margin: '0 auto', padding: '56px 32px' } },
          R.createElement('h3', { style: { fontSize: 24, fontWeight: 700, margin: '0 0 24px' } }, 'Related insights'),
          R.createElement('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 16 } },
            [['Article', 'The operating model for AI'], ['Article', 'Cost-to-serve, rebuilt'], ['Study', 'Trust in digital public services']].map(([k, t]) =>
              R.createElement(Card, { key: t, interactive: true, onClick: () => go('article'), style: { display: 'flex', flexDirection: 'column', gap: 10 } },
                R.createElement(Badge, { variant: 'neutral' }, k),
                R.createElement('div', { style: { fontSize: 17, fontWeight: 700, lineHeight: 1.3 } }, t)))))));
  }

  /* ============================ CONTACT ============================ */
  function Contact() {
    const [sent, setSent] = R.useState(false);
    return R.createElement('section', { style: { maxWidth: 1200, margin: '0 auto', padding: '64px 32px 96px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 64 } },
      R.createElement('div', null,
        R.createElement('hr', { style: { border: 0, height: 3, width: 56, background: 'var(--bp-red)', margin: '0 0 18px' } }),
        R.createElement('h1', { style: { fontSize: 52, fontWeight: 800, letterSpacing: '-0.025em', margin: 0, lineHeight: 1.05 } }, 'Get in touch'),
        R.createElement('p', { style: { fontSize: 18, color: 'var(--text-secondary)', lineHeight: 1.6, marginTop: 18, maxWidth: 420 } }, 'Tell us about the challenge in front of you. We’ll come back within two working days.'),
        R.createElement('div', { style: { marginTop: 32, display: 'flex', flexDirection: 'column', gap: 16 } },
          [['Offices', '24 countries across Europe, the Americas & Asia'], ['Media', 'press@bearingpoint.com'], ['Careers', 'Join 6,000+ people who think beyond the obvious']].map(([h, d]) =>
            R.createElement('div', { key: h, style: { paddingLeft: 14, borderLeft: '3px solid var(--bp-black)' } },
              R.createElement('div', { style: { fontFamily: 'var(--font-mono)', fontSize: 11, textTransform: 'uppercase', letterSpacing: '.12em', color: 'var(--text-muted)' } }, h),
              R.createElement('div', { style: { fontSize: 15, marginTop: 4 } }, d))))),
      R.createElement(Card, { style: { alignSelf: 'start' } },
        sent
          ? R.createElement('div', { style: { padding: '32px 8px', textAlign: 'center' } },
              R.createElement('div', { style: { fontSize: 22, fontWeight: 700 } }, 'Thank you.'),
              R.createElement('p', { style: { color: 'var(--text-secondary)', marginTop: 8 } }, 'Your message is on its way. We’ll be in touch shortly.'),
              R.createElement(Button, { variant: 'ghost', onClick: () => setSent(false), style: { marginTop: 8 } }, 'Send another'))
          : R.createElement('div', { style: { display: 'flex', flexDirection: 'column', gap: 16 } },
              R.createElement('div', { style: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 } },
                R.createElement(Input, { label: 'First name', placeholder: 'Anna' }),
                R.createElement(Input, { label: 'Last name', placeholder: 'Berg' })),
              R.createElement(Input, { label: 'Work email', placeholder: 'you@company.com', type: 'email' }),
              R.createElement(Select, { label: 'Topic', placeholder: 'Choose…', options: ['Strategy & Growth', 'Finance & Risk', 'Operations', 'Technology', 'People & Change'] }),
              R.createElement(DS.Textarea, { label: 'How can we help?', rows: 4, placeholder: 'Tell us about your challenge…' }),
              R.createElement(Button, { variant: 'accent', fullWidth: true, onClick: () => setSent(true) }, 'Send message'))));
  }

  /* ============================ APP ============================ */
  function SiteApp() {
    const [route, setRoute] = R.useState('home');
    const go = (r) => { setRoute(r); document.getElementById('scroll-root') && (document.getElementById('scroll-root').scrollTop = 0); };
    const pages = { home: Home, insights: Insights, article: Article, contact: Contact };
    const Page = pages[route] || Home;
    return R.createElement('div', { className: 'bp-base', style: { minHeight: '100%' } },
      R.createElement(Header, { nav: route, go }),
      R.createElement(Page, { go }),
      R.createElement(Footer, { go }));
  }

  window.SiteApp = SiteApp;
})();
