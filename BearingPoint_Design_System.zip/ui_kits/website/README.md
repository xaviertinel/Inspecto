# Website UI kit — BearingPoint

A brand-accurate recreation of the **bearingpoint.com** marketing surface, built entirely on the design-system primitives (`Button`, `Card`, `Badge`, `Tabs`, `Input`, `Select`, `Logo`, …).

## Screens (click-through in `index.html`)
- **Home** — black hero ("Beyond the obvious."), deep-red stat band, services grid, insights, red CTA.
- **Insights** — filterable list of reports / articles / studies.
- **Article** — long-form report with author, pull-quote callout, related items.
- **Contact** — split layout with a working (fake) contact form.

Navigate via the header nav, the "Get in touch" button, and insight cards.

## Files
- `index.html` — loads React + the compiled DS bundle + `site.js`, renders `<SiteApp/>`.
- `site.js` — plain-JS (no JSX) definitions of `Header`, `Footer`, `Home`, `Insights`, `Article`, `Contact`, `SiteApp` → `window.SiteApp`.

## Notes / caveats
- This kit is composed from the **brand foundations** (color, type, layout rules from the official PPT template + logo), not pixel-copied from a Figma or the live site's code — no source code was provided. Treat spacing/hero copy as brand-consistent placeholders.
- **Imagery** is represented with brand color blocks (black / deep-red / warm-gray) since no photography was supplied. Swap in real photography or `<image-slot>`s where the gray blocks appear.
