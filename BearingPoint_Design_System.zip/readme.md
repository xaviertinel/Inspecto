# BearingPoint Design System

A brand-accurate design system for **BearingPoint** — an independent management and technology consultancy with European roots and a global reach, offering Consulting, Products and Capital services. The brand voice is confident, precise and understated; the identity is deliberately austere — black, white, warm neutral grays, and a single vivid red used only to highlight.

> **Tagline:** *Beyond the obvious.*

## Sources used to build this system
- **`uploads/BearingPoint ppt_tmpl.pdf`** — the official PowerPoint template + colour-usage guide (24 pages). The colour rules, allowed backgrounds, text rules and the consultant-profile layout were read from here. *(The PDF embeds very large rasters and could not be page-rendered; its colour swatches were sampled from the vector fills and its typography read from the embedded fonts.)*
- **Logos** — `uploads/BearingPoint_Logotype_{Black,White}_RGB.png` and `…_Symbol_{Black,White}_RGB.png`, copied into `assets/logos/`.
- **bearingpoint.com** — referenced for brand context and product/industry taxonomy (management & technology consulting; industries incl. banking, insurance, automotive, public sector, utilities; services incl. strategy, finance & risk, operations, technology, people).

No source code or Figma file was supplied, so the UI kit and slides are composed from these brand **foundations** rather than pixel-copied from the live product. See caveats at the bottom.

---

## Content fundamentals — how BearingPoint writes

- **Tone:** confident, plain-spoken, senior. Reads like a partner talking to a board — no hype, no jargon soup. Short declarative sentences. "Beyond the obvious" is the north star: say the non-obvious thing, plainly.
- **Voice / person:** "we" (the firm) and "you / your organisation" (the client). Collective, advisory, never boastful in the first person singular.
- **Casing:** **Title/sentence case** for headlines and body. UPPERCASE is reserved for small mono eyebrow labels and the `© BEARINGPOINT` footer — never for headlines.
- **Emphasis:** through **bold**, *italics* or <u>underline</u> and through the red *highlight* — **never** by colouring the text itself. Text is only ever black or white.
- **Punctuation & numbers:** figures are precise and often mono-set (`€2.4bn`, `−24%`, `2.3×`, `72%`). Curly quotes. Sparse exclamation. Em dashes for asides.
- **No emoji.** Ever. The brand is serious and restrained.
- **Example headlines:** "Beyond the obvious." · "The connected enterprise, rebuilt." · "Let's turn ambition into results." · "Where the value actually sits."
- **Eyebrows / labels:** short, mono, uppercase, tracked — e.g. `MANAGEMENT & TECHNOLOGY CONSULTING`, `FINANCE & RISK`, `CLIENT BRIEFING · 2026`.

---

## Visual foundations

- **Colour:** black `#000` and white `#fff` do most of the work over **warm** neutral grays (extracted `#E6DEDA` / `#CCC1BC` — noticeably taupe, not cool). **BearingPoint Red `#FF3D47`** is the single accent, used *only to highlight* a key data point, fact or message — via the graphic itself or an arrow/rule leading to it, **never on running text**. **Deep Red `#330000`** is an allowed solid background. A **purple** ramp exists strictly as a graphics extension when the reds and grays run out of categories. The only four allowed solid backgrounds are **White, Gray, BearingPoint Red, Deep Red**.
- **Typography:** one grotesque family, **Hanken Grotesk** (substitute — see below), across display and body; **IBM Plex Mono** for eyebrows, figures, footers and code. Display is tightly tracked (−0.02em) and bold/extrabold (700–800); body is 16px / 1.5. Text is **left-aligned, never justified**.
- **Layout:** generous clear space, a 4px spacing grid, wide side margins (80px on slides, 32px on web). Content is left-anchored. A short **heavy red rule (3–4px × ~56px)** sits under eyebrows and section titles as the signature emphasis mark.
- **Backgrounds:** flat solid colour only — **no gradients**, no photo-darkening, no texture. Full-bleed brand-colour panels (black / deep-red / red) carry hero and divider moments. The B° ring occasionally appears oversized and low-contrast as a watermark device.
- **Corners & borders:** sharp. Radii are small (0–4px); cards use 4px and a **1px hairline** border in warm gray. The one soft geometry is the perfect circle of the B° symbol (and avatars/toggles that echo it). Pills (999px) are used for tags and toggles.
- **Shadow:** minimal and **neutral** (never coloured). `sm` for resting cards, `lg` only on hover-lift. Most surfaces rely on the hairline border instead of shadow.
- **Elevation / cards:** white surface, 1px warm-gray border, small radius, `shadow-sm`. Interactive cards lift 2px with `shadow-lg` on hover. A highlighted card gets a thin red top rule (`accentBar`).
- **Motion:** quick and precise — 120–280ms on a `cubic-bezier(0.2,0,0,1)` standard ease. Fades and short slides; **no bounce**, no springy overshoot. Respect `prefers-reduced-motion`.
- **Hover / press states:** solid buttons darken (black → `neutral-800`, red → `red-hover #E42630`); ghost/secondary fill with a faint warm gray; press nudges down 1px. Focus shows a black border + a soft red ring (`shadow-focus`).
- **Transparency / blur:** used sparingly — white text at 60–78% opacity on dark panels; hairlines at ~16% white on black. No glass/backdrop-blur.
- **Imagery vibe:** when photography is used it is clean, well-lit and undarkened, warm-neutral in cast, with type kept fully legible over it. This system ships **no photography**; brand-colour blocks stand in for images (swap in real assets).

---

## Iconography

- BearingPoint does **not** ship a public icon font or sprite, and none was supplied. The system therefore uses **[Lucide](https://lucide.dev)** — a clean line set with a consistent **2px stroke, round caps/joins** that matches the brand's precise, understated character. *(Substitution — flagged. Swap for the official icon set if BearingPoint provides one.)*
  - In components and UI kits, icons are passed as elements (e.g. `iconRight={<ArrowIcon/>}`) and drawn as inline `<svg>` with `stroke: currentColor`, so they inherit text colour. Small local Lucide-style paths are used inline in the kit.
- **No emoji** anywhere in the brand.
- **Unicode as icon:** only the arrow motif (→) and the `×` dismiss glyph are used as characters; everything else is line SVG.
- **The B° symbol** (`assets/logos/…-symbol-…`) doubles as the brand's iconographic device — favicon, avatar, app tile, oversized watermark ring.

---

## Index — what's in this project

**Foundations (root)**
- `styles.css` — the single entry point consumers link (an `@import` manifest only).
- `tokens/` — `fonts.css`, `colors.css`, `typography.css`, `spacing.css`, `base.css`.
- `assets/logos/` — wordmark & B° symbol, black + white.
- `guidelines/*.card.html` — foundation specimen cards (Colors, Type, Spacing, Brand).

**Components** (`components/…`, namespace `window.BearingPointDesignSystem_4216a8`)
- `core/` — **Button, IconButton, Badge, Tag, Card, StatCard, Avatar, Divider, Logo**
- `forms/` — **Input, Textarea, Select, Checkbox, Radio, Switch**
- `feedback/` — **Tabs, ProgressBar, Callout, Tooltip, Toast**
- Each component: `Name.jsx` + `Name.d.ts` + `Name.prompt.md`; one `*.card.html` per directory.

**UI kits** (`ui_kits/…`)
- `website/` — brand-accurate marketing site: Home · Insights · Article · Contact (interactive click-through). See `ui_kits/website/README.md`.

**Slides** (`slides/*.slide.html`) — sample deck built from the PPT template rules: Title, Section divider, Content + highlight, Stats, Quote, Comparison, Consultant profile, Closing.

**Other**
- `SKILL.md` — makes this system usable as a downloadable Agent Skill.
- `research/` — extracted notes from the source PPT.

---

## Caveats & open questions

- **Fonts are substituted.** The BearingPoint wordmark is a proprietary geometric grotesque and the official template falls back to **Helvetica** for body — neither is web-licensable here. The system uses **Hanken Grotesk** (display + body) and **IBM Plex Mono** (labels/data). *Please provide the licensed BearingPoint typeface + Helvetica/Arial files if you'd like exact fidelity — swap them into `tokens/fonts.css`.*
- **Icons are substituted** with Lucide (see Iconography). Swap if you have an official set.
- **Red value** `#FF3D47` and the neutrals `#E6DEDA` / `#CCC1BC` were sampled from vector fills in the official template; the deep red is `#330000`. If your master brand book lists exact Pantone/hex values, send them and I'll reconcile.
- **UI kit & slides are composed from brand foundations, not a source file.** No codebase or Figma was provided, so hero copy, spacing and structure are brand-consistent placeholders — and **imagery is stand-in colour blocks**. Point me at the real site code / Figma or supply photography for a pixel-exact pass.
