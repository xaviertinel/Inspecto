import React from 'react';

/**
 * BearingPoint Tabs — underline style. The active tab is marked by a heavy
 * black underline; hover shows a faint one. Controlled or uncontrolled.
 */
export function Tabs({
  tabs = [],            // [{id, label}] or string[]
  value = null,
  defaultValue = null,
  onChange,
  style = {},
  ...rest
}) {
  const items = tabs.map((t) => (typeof t === 'string' ? { id: t, label: t } : t));
  const [internal, setInternal] = React.useState(defaultValue ?? (items[0] && items[0].id));
  const active = value ?? internal;
  const [hover, setHover] = React.useState(null);

  const select = (id) => { setInternal(id); onChange && onChange(id); };

  return (
    <div role="tablist" style={{ display: 'flex', gap: 4, borderBottom: '1px solid var(--border-default)', ...style }} {...rest}>
      {items.map((t) => {
        const isActive = t.id === active;
        return (
          <button
            key={t.id}
            role="tab"
            aria-selected={isActive}
            onClick={() => select(t.id)}
            onMouseEnter={() => setHover(t.id)}
            onMouseLeave={() => setHover(null)}
            style={{
              appearance: 'none', background: 'none', border: 'none', cursor: 'pointer',
              fontFamily: 'var(--font-sans)', fontSize: 'var(--text-body-md)',
              fontWeight: isActive ? 'var(--weight-semibold)' : 'var(--weight-medium)',
              color: isActive ? 'var(--text-primary)' : 'var(--text-secondary)',
              padding: '12px 14px', position: 'relative', whiteSpace: 'nowrap',
              transition: 'color var(--duration-fast) var(--ease-standard)',
            }}
          >
            {t.label}
            <span style={{
              position: 'absolute', left: 0, right: 0, bottom: -1, height: isActive ? 2 : (hover === t.id ? 2 : 0),
              background: isActive ? 'var(--bp-black)' : 'var(--bp-neutral-300)',
              transition: 'height var(--duration-fast) var(--ease-standard)',
            }} />
          </button>
        );
      })}
    </div>
  );
}
