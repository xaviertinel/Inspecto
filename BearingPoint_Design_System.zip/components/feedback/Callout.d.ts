import * as React from 'react';

/** Bordered message block with a left rule. `highlight` uses the red rule. */
export interface CalloutProps {
  children?: React.ReactNode;
  title?: React.ReactNode;
  tone?: 'neutral' | 'highlight';
  icon?: React.ReactNode;
  style?: React.CSSProperties;
}
export function Callout(props: CalloutProps): JSX.Element;
