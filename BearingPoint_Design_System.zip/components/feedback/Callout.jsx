import React from 'react';

/**
 * BearingPoint Callout — a bordered message block. A left rule marks it; the
 * `highlight` tone uses the red rule to draw attention to a key message.
 */
export function Callout({
  children,
  title = null,
  tone = 'neutral',   // neutral | highlight
  icon = null,
  style = {},
  ...rest
}) {
  const rule = tone === 'highlight' ? 'var(--bp-red)' : 'var(--bp-black)';
  return (
    <div
      style={{
        display: 'flex', gap: 12,
        borderLeft: `var(--border-width-heavy) solid ${rule}`,
        background: 'var(--bp-neutral-50)',
        padding: 'var(--space-4) var(--space-5)',
        borderRadius: '0 var(--radius-sm) var(--radius-sm) 0',
        ...style,
      }}
      {...rest}
    >
      {icon && <span style={{ width: 18, height: 18, flexShrink: 0, marginTop: 1, color: 'var(--text-primary)' }}>{icon}</span>}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
        {title && <span style={{ fontWeight: 'var(--weight-semibold)', fontSize: 'var(--text-body-md)', color: 'var(--text-primary)' }}>{title}</span>}
        <span style={{ fontSize: 'var(--text-body-sm)', color: 'var(--text-secondary)', lineHeight: 1.55 }}>{children}</span>
      </div>
    </div>
  );
}
