import React from 'react';

/** BearingPoint Tooltip — black bubble on hover/focus. Wraps its trigger. */
export function Tooltip({
  children,
  label,
  placement = 'top',   // top | bottom
  style = {},
  ...rest
}) {
  const [open, setOpen] = React.useState(false);
  const pos = placement === 'bottom'
    ? { top: 'calc(100% + 8px)' }
    : { bottom: 'calc(100% + 8px)' };
  return (
    <span
      style={{ position: 'relative', display: 'inline-flex' }}
      onMouseEnter={() => setOpen(true)}
      onMouseLeave={() => setOpen(false)}
      onFocus={() => setOpen(true)}
      onBlur={() => setOpen(false)}
      {...rest}
    >
      {children}
      {open && (
        <span
          role="tooltip"
          style={{
            position: 'absolute', left: '50%', transform: 'translateX(-50%)', ...pos,
            background: 'var(--bp-black)', color: 'var(--bp-white)',
            fontFamily: 'var(--font-sans)', fontSize: 'var(--text-caption)', fontWeight: 'var(--weight-medium)',
            padding: '6px 10px', borderRadius: 'var(--radius-sm)', whiteSpace: 'nowrap',
            boxShadow: 'var(--shadow-md)', zIndex: 50, pointerEvents: 'none',
            ...style,
          }}
        >
          {label}
        </span>
      )}
    </span>
  );
}
