import * as React from 'react';

/** Notification surface (dark). `accent` adds a red leading rule. */
export interface ToastProps {
  title?: React.ReactNode;
  children?: React.ReactNode;
  accent?: boolean;
  onClose?: () => void;
  style?: React.CSSProperties;
}
export function Toast(props: ToastProps): JSX.Element;
