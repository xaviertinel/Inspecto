import React from 'react';

/** BearingPoint ProgressBar — thin track. Black fill by default; `accent`
 * fills with BearingPoint red to highlight a headline metric. */
export function ProgressBar({
  value = 0,            // 0–100
  accent = false,
  showLabel = false,
  height = 6,
  style = {},
  ...rest
}) {
  const pct = Math.max(0, Math.min(100, value));
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12, ...style }} {...rest}>
      <div style={{ flex: 1, height, background: 'var(--bp-neutral-200)', borderRadius: 'var(--radius-pill)', overflow: 'hidden' }}>
        <div style={{
          width: `${pct}%`, height: '100%',
          background: accent ? 'var(--bp-red)' : 'var(--bp-black)',
          borderRadius: 'var(--radius-pill)',
          transition: 'width var(--duration-slow) var(--ease-out)',
        }} />
      </div>
      {showLabel && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-body-sm)', color: 'var(--text-secondary)', minWidth: 40, textAlign: 'right' }}>{pct}%</span>}
    </div>
  );
}
