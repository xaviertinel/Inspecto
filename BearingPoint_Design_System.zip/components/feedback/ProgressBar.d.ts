import * as React from 'react';

/** Thin progress track. `accent` fills red to highlight a metric. */
export interface ProgressBarProps {
  value?: number;
  accent?: boolean;
  showLabel?: boolean;
  height?: number;
  style?: React.CSSProperties;
}
export function ProgressBar(props: ProgressBarProps): JSX.Element;
