import * as React from 'react';

/** Black tooltip bubble on hover/focus. Wraps its trigger element. */
export interface TooltipProps {
  children?: React.ReactNode;
  label: React.ReactNode;
  placement?: 'top' | 'bottom';
  style?: React.CSSProperties;
}
export function Tooltip(props: TooltipProps): JSX.Element;
