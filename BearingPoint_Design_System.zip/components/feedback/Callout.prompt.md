# Callout

Bordered message block with a heavy left rule. `neutral` (black rule) for general notes; `highlight` (red rule) to draw attention to a key message.

```jsx
<Callout title="Key finding">Cost-to-serve fell 24% in the first two quarters.</Callout>
<Callout tone="highlight" title="Recommendation">Consolidate to a single platform.</Callout>
```
