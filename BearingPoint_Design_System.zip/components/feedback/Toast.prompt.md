# Toast

Dark notification surface with title, body and optional dismiss. `accent` adds a red leading rule for an important message.

```jsx
<Toast title="Saved" onClose={dismiss}>Your changes are live.</Toast>
<Toast title="Deadline near" accent>Submission closes in 2 days.</Toast>
```
