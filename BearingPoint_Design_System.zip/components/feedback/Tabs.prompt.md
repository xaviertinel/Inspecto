# Tabs

Underline tab bar. The active tab carries a heavy black underline; hover shows a faint gray one. `tabs` may be strings or `{id,label}`. Controlled (`value`+`onChange`) or uncontrolled (`defaultValue`).

```jsx
<Tabs tabs={['Overview','Approach','Results']} onChange={setTab} />
```
