import React from 'react';

/** BearingPoint Toast — a self-contained notification surface. Black by
 * default; `accent` shows a red leading rule for an important message. */
export function Toast({
  title = null,
  children,
  accent = false,
  onClose = null,
  style = {},
  ...rest
}) {
  return (
    <div
      role="status"
      style={{
        display: 'flex', alignItems: 'flex-start', gap: 12,
        background: 'var(--bp-neutral-900)', color: 'var(--bp-white)',
        borderLeft: accent ? 'var(--border-width-heavy) solid var(--bp-red)' : 'var(--border-width-heavy) solid var(--bp-neutral-900)',
        padding: 'var(--space-4) var(--space-5)',
        borderRadius: 'var(--radius-sm)', boxShadow: 'var(--shadow-lg)',
        minWidth: 280, maxWidth: 420,
        ...style,
      }}
      {...rest}
    >
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 2 }}>
        {title && <span style={{ fontWeight: 'var(--weight-semibold)', fontSize: 'var(--text-body-md)' }}>{title}</span>}
        <span style={{ fontSize: 'var(--text-body-sm)', color: 'var(--text-inverse-soft)', lineHeight: 1.5 }}>{children}</span>
      </div>
      {onClose && (
        <button aria-label="Dismiss" onClick={onClose} style={{ background: 'none', border: 'none', color: 'var(--text-inverse-soft)', cursor: 'pointer', fontSize: 16, lineHeight: 1, padding: 2 }}>×</button>
      )}
    </div>
  );
}
