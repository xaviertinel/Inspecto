import * as React from 'react';

interface TabItem { id: string; label: React.ReactNode; }
/** Underline tabs. `tabs` may be strings or {id,label}. Controlled via value/onChange. */
export interface TabsProps {
  tabs?: (string | TabItem)[];
  value?: string | null;
  defaultValue?: string | null;
  onChange?: (id: string) => void;
  style?: React.CSSProperties;
}
export function Tabs(props: TabsProps): JSX.Element;
