# Tooltip

Black tooltip bubble shown on hover/focus of its wrapped trigger.

```jsx
<Tooltip label="Export as PDF"><IconButton aria-label="Export"><DownloadIcon /></IconButton></Tooltip>
```
