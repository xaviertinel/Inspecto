# ProgressBar

Thin progress track. Black fill by default; `accent` fills with BearingPoint red to highlight a headline metric. Optional `showLabel`.

```jsx
<ProgressBar value={72} showLabel />
<ProgressBar value={90} accent />
```
