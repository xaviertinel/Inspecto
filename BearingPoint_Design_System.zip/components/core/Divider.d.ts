import * as React from 'react';

/** Hairline rule. `accent` renders the short heavy red emphasis bar. */
export interface DividerProps {
  orientation?: 'horizontal' | 'vertical';
  accent?: boolean;
  style?: React.CSSProperties;
}
export function Divider(props: DividerProps): JSX.Element;
