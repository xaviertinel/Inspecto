import * as React from 'react';

/**
 * BearingPoint primary button. Sharp corners, semibold. Black by default;
 * the `accent` (red) variant is reserved for the single most important CTA.
 *
 * @startingPoint section="Core" subtitle="Primary / secondary / ghost / accent button" viewport="700x150"
 */
export interface ButtonProps {
  children?: React.ReactNode;
  /** Visual style. @default "primary" */
  variant?: 'primary' | 'secondary' | 'ghost' | 'accent';
  /** @default "md" */
  size?: 'sm' | 'md' | 'lg';
  /** Icon element rendered before the label. */
  iconLeft?: React.ReactNode;
  /** Icon element rendered after the label. */
  iconRight?: React.ReactNode;
  disabled?: boolean;
  fullWidth?: boolean;
  type?: 'button' | 'submit' | 'reset';
  onClick?: (e: React.MouseEvent<HTMLButtonElement>) => void;
  style?: React.CSSProperties;
}

export function Button(props: ButtonProps): JSX.Element;
