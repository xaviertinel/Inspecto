import React from 'react';

/**
 * BearingPoint Card — crisp white surface, hairline border, minimal shadow.
 * `interactive` adds a hover lift. `accentBar` draws a thin red rule along
 * the top edge to mark a highlighted card.
 */
export function Card({
  children,
  interactive = false,
  accentBar = false,
  padding = 'var(--space-6)',
  style = {},
  onClick,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        position: 'relative',
        background: 'var(--surface-card)',
        border: '1px solid var(--border-default)',
        borderRadius: 'var(--radius-md)',
        padding,
        boxShadow: interactive && hover ? 'var(--shadow-lg)' : 'var(--shadow-sm)',
        transform: interactive && hover ? 'translateY(-2px)' : 'none',
        transition: 'box-shadow var(--duration-base) var(--ease-standard), transform var(--duration-base) var(--ease-standard)',
        cursor: interactive ? 'pointer' : 'default',
        overflow: 'hidden',
        ...style,
      }}
      {...rest}
    >
      {accentBar && (
        <span style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 'var(--border-width-heavy)', background: 'var(--bp-red)' }} />
      )}
      {children}
    </div>
  );
}
