import * as React from 'react';

/** Big mono figure + label + optional delta. `highlight` tints the figure red. */
export interface StatCardProps {
  value: React.ReactNode;
  label?: React.ReactNode;
  eyebrow?: React.ReactNode;
  delta?: React.ReactNode;
  highlight?: boolean;
  style?: React.CSSProperties;
}
export function StatCard(props: StatCardProps): JSX.Element;
