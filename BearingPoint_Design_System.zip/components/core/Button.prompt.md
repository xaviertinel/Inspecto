# Button

A primary action control — sharp-cornered, semibold. Use `primary` (black) for the default action, `secondary` for lower emphasis, `ghost` for tertiary/inline, and `accent` (BearingPoint red) for the single most important call to action on a view. Never set label text in red.

```jsx
<Button variant="primary">Get in touch</Button>
<Button variant="secondary" iconRight={<ArrowIcon />}>Read the report</Button>
<Button variant="accent" size="lg">Book a briefing</Button>
<Button variant="ghost" size="sm">Cancel</Button>
```

Props: `variant` (primary·secondary·ghost·accent), `size` (sm·md·lg), `iconLeft`/`iconRight`, `disabled`, `fullWidth`.
