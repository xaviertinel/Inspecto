# Divider

Hairline rule for separating content. `accent` renders the short heavy red emphasis bar used under eyebrows and section titles.

```jsx
<Divider />
<Divider orientation="vertical" />
<Divider accent />
```
