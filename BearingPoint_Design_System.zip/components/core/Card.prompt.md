# Card

Crisp white content surface with a hairline border and minimal shadow. `interactive` adds a hover lift; `accentBar` draws the thin red top rule to mark a highlighted card.

```jsx
<Card>…</Card>
<Card interactive onClick={...}>…</Card>
<Card accentBar>Featured insight</Card>
```
