import * as React from 'react';

/**
 * Content surface — hairline border, minimal shadow, sharp-ish corners.
 * @startingPoint section="Core" subtitle="White card surface with optional red accent bar" viewport="700x220"
 */
export interface CardProps {
  children?: React.ReactNode;
  /** Adds hover lift + pointer. */
  interactive?: boolean;
  /** Thin red rule along the top edge to mark a highlight card. */
  accentBar?: boolean;
  padding?: string;
  onClick?: (e: React.MouseEvent) => void;
  style?: React.CSSProperties;
}
export function Card(props: CardProps): JSX.Element;
