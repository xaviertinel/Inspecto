# Badge

Compact status token — mono, uppercase, tracked. Use for statuses, categories, counts. `accent` (red) marks a genuine highlight only.

```jsx
<Badge>Draft</Badge>
<Badge variant="solid">Live</Badge>
<Badge variant="accent">New</Badge>
<Badge variant="outline" shape="pill">Banking</Badge>
```

Variants: `neutral·subtle·solid·outline·accent`. `shape`: square·pill. `size`: sm·md.
