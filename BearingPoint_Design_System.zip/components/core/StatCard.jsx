import React from 'react';

/**
 * BearingPoint StatCard — a big figure with label and optional delta. The
 * figure is mono; a positive/negative delta may be tinted red to highlight
 * a key data point (the one place red touches near-text is allowed as a
 * highlight of a data point, not running copy).
 */
export function StatCard({
  value,
  label,
  eyebrow = null,
  delta = null,          // e.g. "+18%"
  highlight = false,     // renders the figure in red
  style = {},
  ...rest
}) {
  return (
    <div
      style={{
        display: 'flex', flexDirection: 'column', gap: 6,
        padding: 'var(--space-6)',
        background: 'var(--surface-card)',
        border: '1px solid var(--border-default)',
        borderRadius: 'var(--radius-md)',
        ...style,
      }}
      {...rest}
    >
      {eyebrow && (
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-eyebrow)', textTransform: 'uppercase', letterSpacing: 'var(--tracking-eyebrow)', color: 'var(--text-secondary)' }}>{eyebrow}</span>
      )}
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 10 }}>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 40, fontWeight: 'var(--weight-semibold)', letterSpacing: '-0.02em', lineHeight: 1, color: highlight ? 'var(--bp-red)' : 'var(--text-primary)' }}>{value}</span>
        {delta && (
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 14, fontWeight: 'var(--weight-medium)', color: 'var(--bp-red)' }}>{delta}</span>
        )}
      </div>
      {label && <span style={{ fontSize: 'var(--text-body-sm)', color: 'var(--text-secondary)', lineHeight: 1.4 }}>{label}</span>}
    </div>
  );
}
