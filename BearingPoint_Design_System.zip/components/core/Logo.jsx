import React from 'react';

/**
 * BearingPoint Logo. Renders the wordmark or the B° symbol as an <img>.
 * Because the artwork lives in this design system's /assets, pass `src`
 * (or `basePath`) so the URL resolves from wherever you mount it. Defaults
 * assume the assets sit at `assets/logos/` relative to the page.
 */
export function Logo({
  variant = 'wordmark',   // wordmark | symbol
  color = 'black',        // black | white
  height = 28,
  basePath = 'assets/logos',
  src = null,
  style = {},
  ...rest
}) {
  const file = variant === 'symbol'
    ? (color === 'white' ? 'bearingpoint-symbol-white.png' : 'bearingpoint-symbol-black.png')
    : (color === 'white' ? 'bearingpoint-logotype-white.png' : 'bearingpoint-logotype-black.png');
  const url = src || `${basePath}/${file}`;
  return (
    <img
      src={url}
      alt="BearingPoint"
      style={{ height, width: 'auto', display: 'block', ...style }}
      {...rest}
    />
  );
}
