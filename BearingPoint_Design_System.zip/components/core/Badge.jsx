import React from 'react';

/**
 * BearingPoint Badge — a compact status/label pill or square. Neutral by
 * default; `accent` uses BearingPoint red for a genuine highlight only.
 */
export function Badge({
  children,
  variant = 'neutral',  // neutral | solid | outline | accent | subtle
  shape = 'square',     // square | pill
  size = 'md',          // sm | md
  style = {},
  ...rest
}) {
  const sizes = {
    sm: { padding: '2px 8px', font: '11px' },
    md: { padding: '4px 10px', font: '12px' },
  };
  const s = sizes[size] || sizes.md;
  const variants = {
    neutral: { background: 'var(--bp-neutral-100)', color: 'var(--bp-neutral-700)', border: '1px solid transparent' },
    subtle: { background: 'var(--bp-neutral-50)', color: 'var(--bp-neutral-600)', border: '1px solid var(--border-default)' },
    solid: { background: 'var(--bp-black)', color: 'var(--bp-white)', border: '1px solid var(--bp-black)' },
    outline: { background: 'transparent', color: 'var(--bp-black)', border: '1px solid var(--bp-black)' },
    accent: { background: 'var(--bp-red)', color: 'var(--bp-white)', border: '1px solid var(--bp-red)' },
  };
  return (
    <span
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 5,
        padding: s.padding,
        fontFamily: 'var(--font-mono)',
        fontSize: s.font,
        fontWeight: 'var(--weight-medium)',
        letterSpacing: '0.04em',
        textTransform: 'uppercase',
        lineHeight: 1.2,
        borderRadius: shape === 'pill' ? 'var(--radius-pill)' : 'var(--radius-sm)',
        whiteSpace: 'nowrap',
        ...variants[variant],
        ...style,
      }}
      {...rest}
    >
      {children}
    </span>
  );
}
