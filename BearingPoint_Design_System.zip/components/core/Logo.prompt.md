# Logo

Renders the BearingPoint wordmark or B° symbol. Set `basePath` (folder of the logo PNGs) or an explicit `src` so the URL resolves from your page.

```jsx
<Logo height={28} />
<Logo variant="symbol" color="white" height={40} basePath="assets/logos" />
```
