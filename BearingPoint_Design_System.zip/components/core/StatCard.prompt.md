# StatCard

A headline figure (mono) with label, optional eyebrow and delta. `highlight` renders the figure in BearingPoint red to draw the eye to a key metric.

```jsx
<StatCard eyebrow="Revenue" value="€2.4bn" delta="+18%" label="FY2025 group revenue" />
<StatCard value="72%" label="of clients re-engage" highlight />
```
