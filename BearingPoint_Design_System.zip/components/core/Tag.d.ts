import * as React from 'react';

/** Selectable / removable keyword chip (title-case text). */
export interface TagProps {
  children?: React.ReactNode;
  selected?: boolean;
  /** When provided, renders a × remove affordance. */
  onRemove?: (e: React.MouseEvent) => void;
  onClick?: (e: React.MouseEvent) => void;
  style?: React.CSSProperties;
}
export function Tag(props: TagProps): JSX.Element;
