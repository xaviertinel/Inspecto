import * as React from 'react';

/** Image or initials avatar. Square by default; circle optional. */
export interface AvatarProps {
  src?: string | null;
  name?: string;
  size?: number;
  shape?: 'square' | 'circle';
  style?: React.CSSProperties;
}
export function Avatar(props: AvatarProps): JSX.Element;
