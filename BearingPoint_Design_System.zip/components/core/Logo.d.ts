import * as React from 'react';

/** BearingPoint wordmark / B° symbol. Set `basePath` or `src` so the asset URL resolves. */
export interface LogoProps {
  variant?: 'wordmark' | 'symbol';
  color?: 'black' | 'white';
  height?: number;
  /** Directory holding the logo PNGs. @default "assets/logos" */
  basePath?: string;
  /** Explicit image URL, overrides basePath/variant/color. */
  src?: string | null;
  style?: React.CSSProperties;
}
export function Logo(props: LogoProps): JSX.Element;
