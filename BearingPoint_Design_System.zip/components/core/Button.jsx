import React from 'react';

/**
 * BearingPoint Button.
 * Sharp corners, confident weight. Black is the default action; the red
 * "accent" variant is reserved for the single most important call to action
 * on a view (red = highlight). Text is never red.
 */
export function Button({
  children,
  variant = 'primary',   // primary | secondary | ghost | accent
  size = 'md',           // sm | md | lg
  iconLeft = null,
  iconRight = null,
  disabled = false,
  fullWidth = false,
  type = 'button',
  onClick,
  style = {},
  ...rest
}) {
  const sizes = {
    sm: { padding: '7px 14px', font: 'var(--text-body-sm)', gap: 6, icon: 15 },
    md: { padding: '10px 20px', font: 'var(--text-body-md)', gap: 8, icon: 17 },
    lg: { padding: '14px 28px', font: 'var(--text-body-lg)', gap: 9, icon: 19 },
  };
  const s = sizes[size] || sizes.md;

  const variants = {
    primary: { background: 'var(--bp-black)', color: 'var(--bp-white)', border: '1px solid var(--bp-black)' },
    secondary: { background: 'var(--bp-white)', color: 'var(--bp-black)', border: '1px solid var(--bp-black)' },
    ghost: { background: 'transparent', color: 'var(--bp-black)', border: '1px solid transparent' },
    accent: { background: 'var(--bp-red)', color: 'var(--bp-white)', border: '1px solid var(--bp-red)' },
  };

  const base = {
    display: fullWidth ? 'flex' : 'inline-flex',
    width: fullWidth ? '100%' : 'auto',
    alignItems: 'center',
    justifyContent: 'center',
    gap: s.gap,
    padding: s.padding,
    fontFamily: 'var(--font-sans)',
    fontSize: s.font,
    fontWeight: 'var(--weight-semibold)',
    lineHeight: 1,
    letterSpacing: '0.005em',
    borderRadius: 'var(--radius-sm)',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.4 : 1,
    transition: 'background var(--duration-fast) var(--ease-standard), color var(--duration-fast) var(--ease-standard), transform var(--duration-fast) var(--ease-standard)',
    userSelect: 'none',
    whiteSpace: 'nowrap',
    ...variants[variant],
    ...style,
  };

  const hoverMap = {
    primary: 'var(--bp-neutral-800)',
    accent: 'var(--bp-red-hover)',
    secondary: 'var(--bp-neutral-50)',
    ghost: 'var(--bp-neutral-100)',
  };

  const onEnter = (e) => {
    if (disabled) return;
    if (variant === 'secondary' || variant === 'ghost') e.currentTarget.style.background = hoverMap[variant];
    else e.currentTarget.style.background = hoverMap[variant];
  };
  const onLeave = (e) => {
    if (disabled) return;
    e.currentTarget.style.background = variants[variant].background;
  };
  const onDown = (e) => { if (!disabled) e.currentTarget.style.transform = 'translateY(1px)'; };
  const onUp = (e) => { if (!disabled) e.currentTarget.style.transform = 'none'; };

  const iconStyle = { width: s.icon, height: s.icon, flexShrink: 0, display: 'inline-flex' };

  return (
    <button
      type={type}
      disabled={disabled}
      onClick={onClick}
      style={base}
      onMouseEnter={onEnter}
      onMouseLeave={(e) => { onLeave(e); onUp(e); }}
      onMouseDown={onDown}
      onMouseUp={onUp}
      {...rest}
    >
      {iconLeft && <span style={iconStyle}>{iconLeft}</span>}
      {children}
      {iconRight && <span style={iconStyle}>{iconRight}</span>}
    </button>
  );
}
