import React from 'react';

/**
 * BearingPoint Tag — removable/selectable keyword chip (title case, sentence
 * text — unlike Badge which is a mono status token).
 */
export function Tag({
  children,
  selected = false,
  onRemove = null,
  onClick,
  style = {},
  ...rest
}) {
  return (
    <span
      onClick={onClick}
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 7,
        padding: '5px 12px',
        fontFamily: 'var(--font-sans)',
        fontSize: 'var(--text-body-sm)',
        fontWeight: 'var(--weight-medium)',
        lineHeight: 1.3,
        borderRadius: 'var(--radius-pill)',
        cursor: onClick ? 'pointer' : 'default',
        background: selected ? 'var(--bp-black)' : 'var(--bp-white)',
        color: selected ? 'var(--bp-white)' : 'var(--bp-neutral-700)',
        border: selected ? '1px solid var(--bp-black)' : '1px solid var(--border-default)',
        transition: 'all var(--duration-fast) var(--ease-standard)',
        ...style,
      }}
      {...rest}
    >
      {children}
      {onRemove && (
        <button
          aria-label="Remove"
          onClick={(e) => { e.stopPropagation(); onRemove(e); }}
          style={{
            display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
            width: 16, height: 16, borderRadius: '50%', border: 'none', cursor: 'pointer',
            background: 'transparent', color: 'inherit', fontSize: 13, lineHeight: 1, padding: 0,
          }}
        >×</button>
      )}
    </span>
  );
}
