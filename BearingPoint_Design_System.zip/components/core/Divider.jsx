import React from 'react';

/** BearingPoint Divider — a hairline rule. `accent` makes it a short heavy
 * red bar (the brand's signature emphasis mark). */
export function Divider({
  orientation = 'horizontal',  // horizontal | vertical
  accent = false,
  style = {},
  ...rest
}) {
  if (accent) {
    return <hr style={{ border: 0, height: 'var(--border-width-heavy)', width: 56, background: 'var(--bp-red)', margin: 0, ...style }} {...rest} />;
  }
  if (orientation === 'vertical') {
    return <span style={{ display: 'inline-block', width: 1, alignSelf: 'stretch', background: 'var(--border-default)', ...style }} {...rest} />;
  }
  return <hr style={{ border: 0, height: 1, width: '100%', background: 'var(--border-default)', margin: 0, ...style }} {...rest} />;
}
