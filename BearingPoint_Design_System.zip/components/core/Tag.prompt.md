# Tag

Selectable / removable keyword chip in title-case sentence text (distinct from Badge's mono status token). Use for filters and multi-select.

```jsx
<Tag>Automotive</Tag>
<Tag selected onClick={...}>Banking</Tag>
<Tag onRemove={...}>Insurance</Tag>
```
