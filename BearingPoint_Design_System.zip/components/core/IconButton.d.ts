import * as React from 'react';

/** Square, icon-only button. Pass one icon element as children. */
export interface IconButtonProps {
  children?: React.ReactNode;
  variant?: 'ghost' | 'solid' | 'outline' | 'accent';
  size?: 'sm' | 'md' | 'lg';
  disabled?: boolean;
  'aria-label'?: string;
  onClick?: (e: React.MouseEvent<HTMLButtonElement>) => void;
  style?: React.CSSProperties;
}
export function IconButton(props: IconButtonProps): JSX.Element;
