import React from 'react';

/** BearingPoint Avatar — square-ish by default (brand favours sharp corners),
 * or circular via shape="circle". Shows an image or initials. */
export function Avatar({
  src = null,
  name = '',
  size = 40,
  shape = 'square',   // square | circle
  style = {},
  ...rest
}) {
  const initials = name.split(' ').filter(Boolean).slice(0, 2).map((n) => n[0]).join('').toUpperCase();
  const radius = shape === 'circle' ? '50%' : 'var(--radius-sm)';
  return (
    <div
      style={{
        width: size, height: size, flexShrink: 0,
        borderRadius: radius,
        overflow: 'hidden',
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        background: 'var(--bp-neutral-800)',
        color: 'var(--bp-white)',
        fontFamily: 'var(--font-sans)',
        fontWeight: 'var(--weight-semibold)',
        fontSize: Math.round(size * 0.4),
        letterSpacing: '0.02em',
        userSelect: 'none',
        ...style,
      }}
      {...rest}
    >
      {src ? <img src={src} alt={name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : (initials || '?')}
    </div>
  );
}
