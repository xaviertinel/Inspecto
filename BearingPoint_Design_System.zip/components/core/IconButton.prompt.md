# IconButton

Square, icon-only control for toolbars and dense UI. Pass one icon element (e.g. a Lucide SVG) as children and always set `aria-label`.

```jsx
<IconButton aria-label="Search"><SearchIcon /></IconButton>
<IconButton variant="solid" aria-label="Menu"><MenuIcon /></IconButton>
```

Variants: `ghost` (default), `outline`, `solid`, `accent`. Sizes: `sm·md·lg`.
