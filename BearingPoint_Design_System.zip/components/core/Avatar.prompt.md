# Avatar

Person/entity avatar showing an image or initials. Square by default (brand favours sharp corners); `shape="circle"` when needed.

```jsx
<Avatar name="Anna Berg" />
<Avatar src="/a.jpg" name="Anna Berg" size={48} shape="circle" />
```
