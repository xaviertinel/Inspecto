import * as React from 'react';

/** Compact status/label. Mono, uppercase. `accent` = red highlight only. */
export interface BadgeProps {
  children?: React.ReactNode;
  variant?: 'neutral' | 'subtle' | 'solid' | 'outline' | 'accent';
  shape?: 'square' | 'pill';
  size?: 'sm' | 'md';
  style?: React.CSSProperties;
}
export function Badge(props: BadgeProps): JSX.Element;
