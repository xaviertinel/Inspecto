import React from 'react';

/**
 * BearingPoint IconButton — square, icon-only control. Pass a single icon
 * element as children (e.g. a Lucide SVG).
 */
export function IconButton({
  children,
  variant = 'ghost',   // ghost | solid | outline | accent
  size = 'md',         // sm | md | lg
  disabled = false,
  'aria-label': ariaLabel,
  onClick,
  style = {},
  ...rest
}) {
  const sizes = { sm: 30, md: 38, lg: 46 };
  const iconSizes = { sm: 16, md: 18, lg: 22 };
  const dim = sizes[size] || sizes.md;

  const variants = {
    ghost: { background: 'transparent', color: 'var(--bp-black)', border: '1px solid transparent' },
    solid: { background: 'var(--bp-black)', color: 'var(--bp-white)', border: '1px solid var(--bp-black)' },
    outline: { background: 'var(--bp-white)', color: 'var(--bp-black)', border: '1px solid var(--border-default)' },
    accent: { background: 'var(--bp-red)', color: 'var(--bp-white)', border: '1px solid var(--bp-red)' },
  };
  const hover = { ghost: 'var(--bp-neutral-100)', solid: 'var(--bp-neutral-800)', outline: 'var(--bp-neutral-50)', accent: 'var(--bp-red-hover)' };

  return (
    <button
      aria-label={ariaLabel}
      disabled={disabled}
      onClick={onClick}
      onMouseEnter={(e) => { if (!disabled) e.currentTarget.style.background = hover[variant]; }}
      onMouseLeave={(e) => { if (!disabled) e.currentTarget.style.background = variants[variant].background; }}
      style={{
        width: dim, height: dim,
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        borderRadius: 'var(--radius-sm)',
        cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled ? 0.4 : 1,
        transition: 'background var(--duration-fast) var(--ease-standard)',
        ...variants[variant],
        ...style,
      }}
      {...rest}
    >
      <span style={{ width: iconSizes[size], height: iconSizes[size], display: 'inline-flex' }}>{children}</span>
    </button>
  );
}
