# Switch

Pill toggle with a black track when on. Controlled via `checked` + `onChange(next)`.

```jsx
<Switch checked={on} onChange={setOn} label="Email me updates" />
```
