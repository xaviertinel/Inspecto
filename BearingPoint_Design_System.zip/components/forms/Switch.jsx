import React from 'react';

/** BearingPoint Switch — pill toggle, black track when on. */
export function Switch({
  checked = false,
  onChange,
  label = null,
  disabled = false,
  id,
  style = {},
  ...rest
}) {
  return (
    <label htmlFor={id} style={{ display: 'inline-flex', alignItems: 'center', gap: 10, cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? 0.5 : 1, ...style }}>
      <span
        role="switch"
        aria-checked={checked}
        onClick={() => !disabled && onChange && onChange(!checked)}
        style={{
          width: 40, height: 22, flexShrink: 0, borderRadius: 'var(--radius-pill)',
          background: checked ? 'var(--bp-black)' : 'var(--bp-neutral-300)',
          position: 'relative',
          transition: 'background var(--duration-base) var(--ease-standard)',
        }}
      >
        <span style={{
          position: 'absolute', top: 2, left: checked ? 20 : 2,
          width: 18, height: 18, borderRadius: '50%', background: 'var(--bp-white)',
          boxShadow: 'var(--shadow-sm)',
          transition: 'left var(--duration-base) var(--ease-out)',
        }} />
      </span>
      {label && <span style={{ fontSize: 'var(--text-body-md)', color: 'var(--text-primary)' }}>{label}</span>}
      <input id={id} type="checkbox" checked={checked} disabled={disabled} onChange={(e) => onChange && onChange(e.target.checked)} style={{ position: 'absolute', opacity: 0, width: 0, height: 0 }} {...rest} />
    </label>
  );
}
