# Select

Native dropdown with brand chrome and a chevron. `options` accepts strings or `{value,label}`.

```jsx
<Select label="Industry" placeholder="Choose…" options={['Banking','Insurance','Automotive']} />
```
