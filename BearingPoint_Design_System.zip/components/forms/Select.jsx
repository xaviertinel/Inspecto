import React from 'react';

/** BearingPoint Select — native select with brand styling and a chevron. */
export function Select({
  label = null,
  hint = null,
  error = null,
  options = [],       // [{value, label}] or string[]
  placeholder = null,
  disabled = false,
  id,
  style = {},
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const borderColor = error ? 'var(--bp-red)' : focus ? 'var(--bp-black)' : 'var(--border-default)';
  const opts = options.map((o) => (typeof o === 'string' ? { value: o, label: o } : o));
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6, ...style }}>
      {label && <label htmlFor={id} style={{ fontSize: 'var(--text-body-sm)', fontWeight: 'var(--weight-medium)', color: 'var(--text-primary)' }}>{label}</label>}
      <div style={{ position: 'relative', display: 'flex' }}>
        <select
          id={id}
          disabled={disabled}
          onFocus={() => setFocus(true)}
          onBlur={() => setFocus(false)}
          style={{
            appearance: 'none', WebkitAppearance: 'none',
            width: '100%',
            fontFamily: 'var(--font-sans)', fontSize: 'var(--text-body-md)', color: 'var(--text-primary)',
            background: disabled ? 'var(--bp-neutral-50)' : 'var(--bp-white)',
            border: `1px solid ${borderColor}`,
            borderRadius: 'var(--radius-sm)',
            padding: '10px 36px 10px 12px', outline: 'none', cursor: 'pointer',
            boxShadow: focus && !error ? 'var(--shadow-focus)' : 'none',
            transition: 'border-color var(--duration-fast) var(--ease-standard), box-shadow var(--duration-fast) var(--ease-standard)',
          }}
          {...rest}
        >
          {placeholder && <option value="">{placeholder}</option>}
          {opts.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
        </select>
        <span style={{ position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none', color: 'var(--text-secondary)', fontSize: 12 }}>▾</span>
      </div>
      {error && <span style={{ fontSize: 'var(--text-caption)', color: 'var(--bp-red)' }}>{error}</span>}
      {hint && !error && <span style={{ fontSize: 'var(--text-caption)', color: 'var(--text-muted)' }}>{hint}</span>}
    </div>
  );
}
