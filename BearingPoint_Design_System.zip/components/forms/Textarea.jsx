import React from 'react';

/** BearingPoint Textarea — multi-line input matching Input styling. */
export function Textarea({
  label = null,
  hint = null,
  error = null,
  rows = 4,
  disabled = false,
  id,
  style = {},
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const borderColor = error ? 'var(--bp-red)' : focus ? 'var(--bp-black)' : 'var(--border-default)';
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6, ...style }}>
      {label && <label htmlFor={id} style={{ fontSize: 'var(--text-body-sm)', fontWeight: 'var(--weight-medium)', color: 'var(--text-primary)' }}>{label}</label>}
      <textarea
        id={id}
        rows={rows}
        disabled={disabled}
        onFocus={() => setFocus(true)}
        onBlur={() => setFocus(false)}
        style={{
          fontFamily: 'var(--font-sans)', fontSize: 'var(--text-body-md)', color: 'var(--text-primary)',
          background: disabled ? 'var(--bp-neutral-50)' : 'var(--bp-white)',
          border: `1px solid ${borderColor}`,
          borderRadius: 'var(--radius-sm)',
          padding: '10px 12px', resize: 'vertical', outline: 'none',
          boxShadow: focus && !error ? 'var(--shadow-focus)' : 'none',
          transition: 'border-color var(--duration-fast) var(--ease-standard), box-shadow var(--duration-fast) var(--ease-standard)',
          lineHeight: 1.5,
        }}
        {...rest}
      />
      {error && <span style={{ fontSize: 'var(--text-caption)', color: 'var(--bp-red)' }}>{error}</span>}
      {hint && !error && <span style={{ fontSize: 'var(--text-caption)', color: 'var(--text-muted)' }}>{hint}</span>}
    </div>
  );
}
