# Radio

Circular radio with a black dot when selected. Group by shared `name`; `onChange(value)` fires with the option's value.

```jsx
<Radio name="plan" value="a" checked={p==='a'} onChange={setP} label="Advisory" />
<Radio name="plan" value="b" checked={p==='b'} onChange={setP} label="Managed service" />
```
