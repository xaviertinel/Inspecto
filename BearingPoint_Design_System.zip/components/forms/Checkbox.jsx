import React from 'react';

/** BearingPoint Checkbox — square, black when checked. */
export function Checkbox({
  checked = false,
  onChange,
  label = null,
  disabled = false,
  id,
  style = {},
  ...rest
}) {
  return (
    <label htmlFor={id} style={{ display: 'inline-flex', alignItems: 'center', gap: 10, cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? 0.5 : 1, ...style }}>
      <span
        role="checkbox"
        aria-checked={checked}
        onClick={() => !disabled && onChange && onChange(!checked)}
        style={{
          width: 18, height: 18, flexShrink: 0,
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
          border: `1.5px solid ${checked ? 'var(--bp-black)' : 'var(--border-strong)'}`,
          background: checked ? 'var(--bp-black)' : 'var(--bp-white)',
          borderRadius: 'var(--radius-sm)',
          transition: 'all var(--duration-fast) var(--ease-standard)',
        }}
      >
        {checked && (
          <svg width="11" height="11" viewBox="0 0 12 12" fill="none"><path d="M2.5 6.2L4.8 8.5L9.5 3.5" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>
        )}
      </span>
      {label && <span style={{ fontSize: 'var(--text-body-md)', color: 'var(--text-primary)' }}>{label}</span>}
      <input id={id} type="checkbox" checked={checked} disabled={disabled} onChange={(e) => onChange && onChange(e.target.checked)} style={{ position: 'absolute', opacity: 0, width: 0, height: 0 }} {...rest} />
    </label>
  );
}
