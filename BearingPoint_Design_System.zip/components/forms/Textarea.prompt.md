# Textarea

Multi-line text field matching Input styling, with `label`, `hint`, `error`, and `rows`.

```jsx
<Textarea label="How can we help?" rows={5} placeholder="Tell us about your challenge…" />
```
