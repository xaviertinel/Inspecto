import * as React from 'react';

/** Circular radio, black dot when selected. */
export interface RadioProps {
  checked?: boolean;
  onChange?: (value: any) => void;
  label?: React.ReactNode;
  name?: string;
  value?: any;
  disabled?: boolean;
  id?: string;
  style?: React.CSSProperties;
}
export function Radio(props: RadioProps): JSX.Element;
