import * as React from 'react';

interface Option { value: string; label: string; }
/** Native select with brand chrome. `options` may be strings or {value,label}. */
export interface SelectProps extends Omit<React.SelectHTMLAttributes<HTMLSelectElement>, 'placeholder'> {
  label?: React.ReactNode;
  hint?: React.ReactNode;
  error?: React.ReactNode;
  options?: (string | Option)[];
  placeholder?: string;
}
export function Select(props: SelectProps): JSX.Element;
