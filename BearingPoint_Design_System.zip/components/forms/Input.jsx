import React from 'react';

/** BearingPoint text Input. Sharp corners, black focus with red ring. */
export function Input({
  label = null,
  hint = null,
  error = null,
  iconLeft = null,
  size = 'md',        // sm | md | lg
  disabled = false,
  id,
  style = {},
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const sizes = {
    sm: { padding: '7px 10px', font: 'var(--text-body-sm)' },
    md: { padding: '10px 12px', font: 'var(--text-body-md)' },
    lg: { padding: '13px 14px', font: 'var(--text-body-lg)' },
  };
  const s = sizes[size] || sizes.md;
  const borderColor = error ? 'var(--bp-red)' : focus ? 'var(--bp-black)' : 'var(--border-default)';

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6, ...style }}>
      {label && <label htmlFor={id} style={{ fontSize: 'var(--text-body-sm)', fontWeight: 'var(--weight-medium)', color: 'var(--text-primary)' }}>{label}</label>}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 8,
        background: disabled ? 'var(--bp-neutral-50)' : 'var(--bp-white)',
        border: `1px solid ${borderColor}`,
        borderRadius: 'var(--radius-sm)',
        padding: s.padding,
        boxShadow: focus && !error ? 'var(--shadow-focus)' : 'none',
        transition: 'border-color var(--duration-fast) var(--ease-standard), box-shadow var(--duration-fast) var(--ease-standard)',
      }}>
        {iconLeft && <span style={{ width: 16, height: 16, display: 'inline-flex', color: 'var(--text-muted)' }}>{iconLeft}</span>}
        <input
          id={id}
          disabled={disabled}
          onFocus={() => setFocus(true)}
          onBlur={() => setFocus(false)}
          style={{
            flex: 1, border: 'none', outline: 'none', background: 'transparent',
            fontFamily: 'var(--font-sans)', fontSize: s.font, color: 'var(--text-primary)',
            minWidth: 0,
          }}
          {...rest}
        />
      </div>
      {error && <span style={{ fontSize: 'var(--text-caption)', color: 'var(--bp-red)' }}>{error}</span>}
      {hint && !error && <span style={{ fontSize: 'var(--text-caption)', color: 'var(--text-muted)' }}>{hint}</span>}
    </div>
  );
}
