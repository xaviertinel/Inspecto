# Input

Single-line text field with `label`, `hint`, `error`, and optional `iconLeft`. Focus draws a black border with a soft red ring; errors turn the border red.

```jsx
<Input label="Work email" placeholder="you@company.com" type="email" />
<Input label="Company" hint="Legal entity name" />
<Input label="Email" error="Enter a valid email" />
```

Sizes: `sm·md·lg`.
