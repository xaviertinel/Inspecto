import * as React from 'react';

/** Text field with label, hint and error states. Red ring on focus. */
export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: React.ReactNode;
  hint?: React.ReactNode;
  error?: React.ReactNode;
  iconLeft?: React.ReactNode;
  size?: 'sm' | 'md' | 'lg';
}
export function Input(props: InputProps): JSX.Element;
