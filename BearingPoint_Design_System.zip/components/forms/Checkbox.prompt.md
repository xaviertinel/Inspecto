# Checkbox

Square checkbox, black when checked, with optional inline `label`. Controlled via `checked` + `onChange(next)`.

```jsx
<Checkbox checked={ok} onChange={setOk} label="I agree to the terms" />
```
