import React from 'react';

/** BearingPoint Radio — circular, black dot when selected. */
export function Radio({
  checked = false,
  onChange,
  label = null,
  name,
  value,
  disabled = false,
  id,
  style = {},
  ...rest
}) {
  return (
    <label htmlFor={id} style={{ display: 'inline-flex', alignItems: 'center', gap: 10, cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? 0.5 : 1, ...style }}>
      <span
        role="radio"
        aria-checked={checked}
        onClick={() => !disabled && onChange && onChange(value)}
        style={{
          width: 18, height: 18, flexShrink: 0,
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
          border: `1.5px solid ${checked ? 'var(--bp-black)' : 'var(--border-strong)'}`,
          background: 'var(--bp-white)',
          borderRadius: '50%',
          transition: 'all var(--duration-fast) var(--ease-standard)',
        }}
      >
        {checked && <span style={{ width: 9, height: 9, borderRadius: '50%', background: 'var(--bp-black)' }} />}
      </span>
      {label && <span style={{ fontSize: 'var(--text-body-md)', color: 'var(--text-primary)' }}>{label}</span>}
      <input id={id} type="radio" name={name} value={value} checked={checked} disabled={disabled} onChange={() => onChange && onChange(value)} style={{ position: 'absolute', opacity: 0, width: 0, height: 0 }} {...rest} />
    </label>
  );
}
