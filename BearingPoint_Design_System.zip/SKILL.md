---
name: bearingpoint-design
description: Use this skill to generate well-branded interfaces and assets for BearingPoint, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Quick orientation
- **`readme.md`** — the full design guide: content voice, visual foundations, iconography, and an index of everything.
- **`styles.css`** — the single stylesheet to link; it `@import`s all tokens and fonts.
- **`tokens/`** — CSS custom properties (colors, typography, spacing, base). Design against these variables, never hard-coded values.
- **`assets/logos/`** — the BearingPoint wordmark and B° symbol (black + white PNGs).
- **`components/`** — React primitives (`.jsx` + `.d.ts` + `.prompt.md`). Read the `.prompt.md` for usage.
- **`ui_kits/website/`** — a full interactive marketing-site recreation.
- **`slides/`** — sample 1280×720 deck slides applying the brand.

## The five things to never get wrong
1. **Text is only ever black or white** — never red or any other colour. Emphasise with weight, italics or underline.
2. **Red (`#FF3D47`) is a highlight only** — one key data point/message per view, via the graphic or a rule/arrow. Deep Red `#330000` is a background.
3. **Only four solid backgrounds:** White, Gray (`#CCC1BC`), BearingPoint Red, Deep Red.
4. **Sharp corners, hairline borders, flat colour** — no gradients, minimal neutral shadow, warm (taupe) grays.
5. **No emoji.** Left-aligned text, never justified. Title/sentence case; UPPERCASE only for small mono eyebrow labels.

## Substitutions (flag to the user)
- Font: **Hanken Grotesk** + **IBM Plex Mono** stand in for the proprietary BearingPoint typeface + Helvetica.
- Icons: **Lucide** (2px stroke) stands in for any official icon set.
